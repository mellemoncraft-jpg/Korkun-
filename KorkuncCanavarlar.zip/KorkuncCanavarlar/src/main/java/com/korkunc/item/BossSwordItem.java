package com.korkunc.item;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Boss kılıcı: her vuruşta özel bir etki çalıştırır. */
public class BossSwordItem extends SwordItem {
    public interface HitEffect {
        void apply(LivingEntity target, LivingEntity attacker);
    }

    private final HitEffect effect;

    public BossSwordItem(HitEffect effect, Item.Settings settings) {
        super(ToolMaterials.NETHERITE, 4, -2.4f, settings);
        this.effect = effect;
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        this.effect.apply(target, attacker);
        return super.postHit(stack, target, attacker);
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.translatable(this.getTranslationKey() + ".tooltip").formatted(Formatting.GRAY, Formatting.ITALIC));
    }
}
