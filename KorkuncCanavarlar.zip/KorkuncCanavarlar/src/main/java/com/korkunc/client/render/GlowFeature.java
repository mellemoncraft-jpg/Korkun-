package com.korkunc.client.render;

import com.korkunc.entity.BaseBossEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.util.Identifier;

/** Gözler / çekirdek gibi parlayan bölgeleri karanlıkta da gösterir (*_glow.png). */
public class GlowFeature<T extends BaseBossEntity, M extends EntityModel<T>> extends EyesFeatureRenderer<T, M> {
    private final RenderLayer layer;

    public GlowFeature(FeatureRendererContext<T, M> context, Identifier texture) {
        super(context);
        this.layer = RenderLayer.getEyes(texture);
    }

    @Override
    public RenderLayer getEyesTexture() {
        return this.layer;
    }
}
