package com.korkunc.client;

import com.korkunc.KorkuncMod;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class ModModelLayers {
    public static final EntityModelLayer FOREST_FORGOTTEN = layer("forest_forgotten");
    public static final EntityModelLayer CRIMSON_PARASITE = layer("crimson_parasite");
    public static final EntityModelLayer SCULK_SHADOW = layer("sculk_shadow");

    private static EntityModelLayer layer(String name) {
        return new EntityModelLayer(new Identifier(KorkuncMod.MOD_ID, name), "main");
    }
}
