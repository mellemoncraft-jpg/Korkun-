package com.korkunc.client;

import com.korkunc.ModEntities;
import com.korkunc.client.model.CrimsonParasiteModel;
import com.korkunc.client.model.ForestForgottenModel;
import com.korkunc.client.model.SculkShadowModel;
import com.korkunc.client.render.BossRenderer;
import com.korkunc.entity.CrimsonParasiteEntity;
import com.korkunc.entity.ForestForgottenEntity;
import com.korkunc.entity.SculkShadowEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class KorkuncClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.FOREST_FORGOTTEN, ForestForgottenModel::getTexturedModelData);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.CRIMSON_PARASITE, CrimsonParasiteModel::getTexturedModelData);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.SCULK_SHADOW, SculkShadowModel::getTexturedModelData);

        EntityRendererRegistry.register(ModEntities.FOREST_FORGOTTEN, ctx ->
                new BossRenderer<ForestForgottenEntity, ForestForgottenModel>(ctx,
                        new ForestForgottenModel(ctx.getPart(ModModelLayers.FOREST_FORGOTTEN)), 1.6f, 1.0f, "forest_forgotten"));
        EntityRendererRegistry.register(ModEntities.CRIMSON_PARASITE, ctx ->
                new BossRenderer<CrimsonParasiteEntity, CrimsonParasiteModel>(ctx,
                        new CrimsonParasiteModel(ctx.getPart(ModModelLayers.CRIMSON_PARASITE)), 1.0f, 1.0f, "crimson_parasite"));
        EntityRendererRegistry.register(ModEntities.SCULK_SHADOW, ctx ->
                new BossRenderer<SculkShadowEntity, SculkShadowModel>(ctx,
                        new SculkShadowModel(ctx.getPart(ModModelLayers.SCULK_SHADOW)), 0.9f, 0.88f, "sculk_shadow"));
    }
}
