package com.korkunc.client.render;

import com.korkunc.KorkuncMod;
import com.korkunc.entity.BaseBossEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Üç boss için ortak renderer: doku + parlama katmanı + ölçek. */
public class BossRenderer<T extends BaseBossEntity, M extends EntityModel<T>> extends MobEntityRenderer<T, M> {
    private final Identifier texture;
    private final float modelScale;

    public BossRenderer(EntityRendererFactory.Context ctx, M model, float shadowRadius, float modelScale, String name) {
        super(ctx, model, shadowRadius);
        this.texture = new Identifier(KorkuncMod.MOD_ID, "textures/entity/" + name + ".png");
        this.modelScale = modelScale;
        this.addFeature(new GlowFeature<T, M>(this, new Identifier(KorkuncMod.MOD_ID, "textures/entity/" + name + "_glow.png")));
    }

    @Override
    public Identifier getTexture(T entity) {
        return this.texture;
    }

    @Override
    protected void scale(T entity, MatrixStack matrices, float amount) {
        matrices.scale(this.modelScale, this.modelScale, this.modelScale);
    }
}
