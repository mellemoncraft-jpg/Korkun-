package com.korkunc.client.model;

import com.korkunc.entity.SculkShadowEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** OTOMATİK ÜRETİLDİ (tools/generate_assets.py). Elle düzenleme; betiği düzenle. */
public class SculkShadowModel extends SinglePartEntityModel<SculkShadowEntity> {
    private final ModelPart root;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart tail1;
    private final ModelPart tail2;
    private final ModelPart tail3;
    private final ModelPart hornR;
    private final ModelPart armR1;
    private final ModelPart armR1b;
    private final ModelPart armR2;
    private final ModelPart armR2b;
    private final ModelPart wispR;
    private final ModelPart wispRb;
    private final ModelPart hornL;
    private final ModelPart armL1;
    private final ModelPart armL1b;
    private final ModelPart armL2;
    private final ModelPart armL2b;
    private final ModelPart wispL;
    private final ModelPart wispLb;
    public SculkShadowModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = this.torso.getChild("head");
        this.tail1 = this.torso.getChild("tail1");
        this.tail2 = this.tail1.getChild("tail2");
        this.tail3 = this.tail2.getChild("tail3");
        this.hornR = this.head.getChild("hornR");
        this.armR1 = this.torso.getChild("armR1");
        this.armR1b = this.armR1.getChild("armR1b");
        this.armR2 = this.torso.getChild("armR2");
        this.armR2b = this.armR2.getChild("armR2b");
        this.wispR = this.torso.getChild("wispR");
        this.wispRb = this.wispR.getChild("wispRb");
        this.hornL = this.head.getChild("hornL");
        this.armL1 = this.torso.getChild("armL1");
        this.armL1b = this.armL1.getChild("armL1b");
        this.armL2 = this.torso.getChild("armL2");
        this.armL2b = this.armL2.getChild("armL2b");
        this.wispL = this.torso.getChild("wispL");
        this.wispLb = this.wispL.getChild("wispLb");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData d_torso = root.addChild("torso", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-5f, -20f, -3f, 10f, 20f, 6f)
                .uv(40, 58).cuboid(-5.5f, -4f, -3.5f, 11f, 1f, 7f)
                .uv(77, 58).cuboid(-5.5f, -17f, -3.5f, 11f, 1f, 7f)
                .uv(0, 69).cuboid(-5.5f, -19f, -3.5f, 11f, 1f, 7f)
                .uv(86, 69).cuboid(-2.5f, -13f, -3.8f, 5f, 6f, 1f)
                .uv(0, 45).cuboid(-8f, -20f, -3.5f, 16f, 5f, 7f),
                ModelTransform.pivot(0f, -8f, 0f));
        ModelPartData d_head = d_torso.addChild("head", ModelPartBuilder.create()
                .uv(33, 0).cuboid(-4f, -10f, -4f, 8f, 10f, 8f)
                .uv(47, 45).cuboid(-4.5f, -11f, -4.5f, 9f, 3f, 9f)
                .uv(15, 58).cuboid(-3f, 0f, -3f, 6f, 3f, 6f)
                .uv(0, 58).cuboid(-0.5f, -15f, -3f, 1f, 4f, 6f),
                ModelTransform.pivot(0f, -20f, 0f));
        ModelPartData d_tail1 = d_torso.addChild("tail1", ModelPartBuilder.create()
                .uv(84, 0).cuboid(-4f, 0f, -2.5f, 8f, 12f, 5f),
                ModelTransform.pivot(0f, 0f, 0f));
        ModelPartData d_tail2 = d_tail1.addChild("tail2", ModelPartBuilder.create()
                .uv(9, 27).cuboid(-3f, 0f, -2f, 6f, 12f, 4f),
                ModelTransform.pivot(0f, 12f, 0f));
        ModelPartData d_tail3 = d_tail2.addChild("tail3", ModelPartBuilder.create()
                .uv(37, 69).cuboid(-2f, 0f, -1.5f, 4f, 5f, 3f),
                ModelTransform.pivot(0f, 12f, 0f));
        ModelPartData d_hornR = d_head.addChild("hornR", ModelPartBuilder.create()
                .uv(102, 45).cuboid(-1f, -9f, -1f, 2f, 9f, 2f),
                ModelTransform.of(-3f, 42f, 0f, 0f, 0f, -0.5f));
        ModelPartData d_armR1 = d_torso.addChild("armR1", ModelPartBuilder.create()
                .uv(30, 27).cuboid(-1.5f, 0f, -1.5f, 3f, 13f, 3f)
                .uv(52, 69).cuboid(-2f, -1f, -2f, 4f, 4f, 4f),
                ModelTransform.of(-7f, -16f, 0f, 0f, 0f, 0.3f));
        ModelPartData d_armR1b = d_armR1.addChild("armR1b", ModelPartBuilder.create()
                .uv(66, 0).cuboid(-1f, 0f, -1f, 2f, 16f, 2f)
                .uv(99, 69).cuboid(-1.5f, 16f, -1.5f, 3f, 4f, 3f)
                .uv(26, 78).cuboid(-1.5f, 20f, -1.5f, 1f, 4f, 1f)
                .uv(31, 78).cuboid(0.5f, 20f, -1.5f, 1f, 4f, 1f)
                .uv(66, 78).cuboid(-0.5f, 20f, 0.5f, 1f, 3f, 1f),
                ModelTransform.pivot(0f, 13f, 0f));
        ModelPartData d_armR2 = d_torso.addChild("armR2", ModelPartBuilder.create()
                .uv(74, 27).cuboid(-1.5f, 0f, -1.5f, 3f, 12f, 3f),
                ModelTransform.of(-5f, -18f, 0f, 0f, 0f, 2f));
        ModelPartData d_armR2b = d_armR2.addChild("armR2b", ModelPartBuilder.create()
                .uv(111, 0).cuboid(-1f, 0f, -1f, 2f, 15f, 2f)
                .uv(112, 69).cuboid(-1.5f, 15f, -1.5f, 3f, 4f, 3f)
                .uv(36, 78).cuboid(-1.5f, 19f, -1.5f, 1f, 4f, 1f)
                .uv(41, 78).cuboid(0.5f, 19f, -1.5f, 1f, 4f, 1f),
                ModelTransform.of(0f, 12f, 0f, 0f, 0f, 0.5f));
        ModelPartData d_wispR = d_torso.addChild("wispR", ModelPartBuilder.create()
                .uv(43, 27).cuboid(-1f, 0f, -1f, 2f, 14f, 2f),
                ModelTransform.of(-4f, -2f, 0f, 0f, 0f, 0.5f));
        ModelPartData d_wispRb = d_wispR.addChild("wispRb", ModelPartBuilder.create()
                .uv(84, 45).cuboid(-1f, 0f, -1f, 2f, 10f, 2f),
                ModelTransform.of(0f, 14f, 0f, 0f, 0f, -0.6f));
        ModelPartData d_hornL = d_head.addChild("hornL", ModelPartBuilder.create()
                .uv(111, 45).cuboid(-1f, -9f, -1f, 2f, 9f, 2f),
                ModelTransform.of(3f, 42f, 0f, 0f, 0f, 0.5f));
        ModelPartData d_armL1 = d_torso.addChild("armL1", ModelPartBuilder.create()
                .uv(52, 27).cuboid(-1.5f, 0f, -1.5f, 3f, 13f, 3f)
                .uv(69, 69).cuboid(-2f, -1f, -2f, 4f, 4f, 4f),
                ModelTransform.of(7f, -16f, 0f, 0f, 0f, -0.3f));
        ModelPartData d_armL1b = d_armL1.addChild("armL1b", ModelPartBuilder.create()
                .uv(75, 0).cuboid(-1f, 0f, -1f, 2f, 16f, 2f)
                .uv(0, 78).cuboid(-1.5f, 16f, -1.5f, 3f, 4f, 3f)
                .uv(46, 78).cuboid(-1.5f, 20f, -1.5f, 1f, 4f, 1f)
                .uv(51, 78).cuboid(0.5f, 20f, -1.5f, 1f, 4f, 1f)
                .uv(71, 78).cuboid(-0.5f, 20f, 0.5f, 1f, 3f, 1f),
                ModelTransform.pivot(0f, 13f, 0f));
        ModelPartData d_armL2 = d_torso.addChild("armL2", ModelPartBuilder.create()
                .uv(87, 27).cuboid(-1.5f, 0f, -1.5f, 3f, 12f, 3f),
                ModelTransform.of(5f, -18f, 0f, 0f, 0f, -2f));
        ModelPartData d_armL2b = d_armL2.addChild("armL2b", ModelPartBuilder.create()
                .uv(0, 27).cuboid(-1f, 0f, -1f, 2f, 15f, 2f)
                .uv(13, 78).cuboid(-1.5f, 15f, -1.5f, 3f, 4f, 3f)
                .uv(56, 78).cuboid(-1.5f, 19f, -1.5f, 1f, 4f, 1f)
                .uv(61, 78).cuboid(0.5f, 19f, -1.5f, 1f, 4f, 1f),
                ModelTransform.of(0f, 12f, 0f, 0f, 0f, -0.5f));
        ModelPartData d_wispL = d_torso.addChild("wispL", ModelPartBuilder.create()
                .uv(65, 27).cuboid(-1f, 0f, -1f, 2f, 14f, 2f),
                ModelTransform.of(4f, -2f, 0f, 0f, 0f, -0.5f));
        ModelPartData d_wispLb = d_wispL.addChild("wispLb", ModelPartBuilder.create()
                .uv(93, 45).cuboid(-1f, 0f, -1f, 2f, 10f, 2f),
                ModelTransform.of(0f, 14f, 0f, 0f, 0f, 0.6f));
        return TexturedModelData.of(data, 128, 128);
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }

    @Override
    public void setAngles(SculkShadowEntity e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        this.getPart().traverse().forEach(ModelPart::resetTransform);
        float bob = MathHelper.sin(anim * 0.08f);
        float amp = Math.min(limbDistance, 1.0f);
        this.torso.pivotY += bob * 1.2f;
        this.torso.pitch += amp * 0.3f;
        this.tail1.pitch += 0.12f + amp * 0.5f + MathHelper.sin(anim * 0.1f) * 0.08f;
        this.tail1.yaw += MathHelper.sin(anim * 0.07f) * 0.12f;
        this.tail2.pitch += amp * 0.2f + MathHelper.sin(anim * 0.1f - 0.7f) * 0.15f;
        this.tail2.yaw += MathHelper.sin(anim * 0.07f - 0.6f) * 0.15f;
        this.tail3.pitch += MathHelper.sin(anim * 0.1f - 1.4f) * 0.2f;
        this.tail3.yaw += MathHelper.sin(anim * 0.07f - 1.2f) * 0.2f;
        float sway = MathHelper.sin(anim * 0.09f) * 0.08f;
        this.armR1.roll += sway;
        this.armL1.roll -= sway;
        this.armR2.roll += sway * 1.5f;
        this.armL2.roll -= sway * 1.5f;
        this.armR1b.pitch += -0.25f + MathHelper.sin(anim * 0.09f + 0.8f) * 0.15f;
        this.armL1b.pitch += -0.25f + MathHelper.sin(anim * 0.09f + 2.4f) * 0.15f;
        this.armR2b.pitch += MathHelper.sin(anim * 0.07f) * 0.12f;
        this.armL2b.pitch += MathHelper.sin(anim * 0.07f + 1.5f) * 0.12f;
        float w = MathHelper.sin(anim * 0.1f) * 0.15f;
        this.wispR.roll += w;
        this.wispL.roll -= w;
        this.wispRb.roll += MathHelper.sin(anim * 0.1f - 0.8f) * 0.2f;
        this.wispLb.roll -= MathHelper.sin(anim * 0.1f - 0.8f) * 0.2f;
        this.head.yaw += headYaw * 0.017453292f * 0.8f;
        this.head.pitch += headPitch * 0.017453292f * 0.8f;
        if (e.isCasting()) {
            this.armR1.pitch += -1.5f;
            this.armL1.pitch += -1.5f;
            this.armR2.roll += 0.4f;
            this.armL2.roll -= 0.4f;
            this.torso.pitch += -0.1f;
            this.head.pitch += -0.25f;
        } else if (e.isAttacking()) {
            float s = MathHelper.sin(anim * 0.5f);
            this.armR1.pitch += -1.2f + s * 0.7f;
            this.armL1.pitch += -1.2f - s * 0.7f;
        }
    }
}
