package com.korkunc.client.model;

import com.korkunc.entity.ForestForgottenEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** OTOMATİK ÜRETİLDİ (tools/generate_assets.py). Elle düzenleme; betiği düzenle. */
public class ForestForgottenModel extends SinglePartEntityModel<ForestForgottenEntity> {
    private final ModelPart root;
    private final ModelPart legR;
    private final ModelPart footR;
    private final ModelPart legL;
    private final ModelPart footL;
    private final ModelPart body;
    private final ModelPart spikeBack1;
    private final ModelPart spikeBack2;
    private final ModelPart spikeBack3;
    private final ModelPart head;
    private final ModelPart antlerR;
    private final ModelPart tineR;
    private final ModelPart armR;
    private final ModelPart forearmR;
    private final ModelPart handR;
    private final ModelPart thornR;
    private final ModelPart antlerL;
    private final ModelPart tineL;
    private final ModelPart armL;
    private final ModelPart forearmL;
    private final ModelPart handL;
    private final ModelPart thornL;
    public ForestForgottenModel(ModelPart root) {
        this.root = root;
        this.legR = root.getChild("legR");
        this.footR = this.legR.getChild("footR");
        this.legL = root.getChild("legL");
        this.footL = this.legL.getChild("footL");
        this.body = root.getChild("body");
        this.spikeBack1 = this.body.getChild("spikeBack1");
        this.spikeBack2 = this.body.getChild("spikeBack2");
        this.spikeBack3 = this.body.getChild("spikeBack3");
        this.head = this.body.getChild("head");
        this.antlerR = this.head.getChild("antlerR");
        this.tineR = this.antlerR.getChild("tineR");
        this.armR = this.body.getChild("armR");
        this.forearmR = this.armR.getChild("forearmR");
        this.handR = this.forearmR.getChild("handR");
        this.thornR = this.body.getChild("thornR");
        this.antlerL = this.head.getChild("antlerL");
        this.tineL = this.antlerL.getChild("tineL");
        this.armL = this.body.getChild("armL");
        this.forearmL = this.armL.getChild("forearmL");
        this.handL = this.forearmL.getChild("handL");
        this.thornL = this.body.getChild("thornL");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData d_legR = root.addChild("legR", ModelPartBuilder.create()
                .uv(61, 0).cuboid(-4.5f, 0f, -4.5f, 9f, 26f, 9f)
                .uv(13, 84).cuboid(-5f, 5f, -5f, 10f, 4f, 10f)
                .uv(140, 84).cuboid(-5f, 14f, -5f, 10f, 3f, 10f),
                ModelTransform.pivot(-7f, -6f, 0f));
        ModelPartData d_footR = d_legR.addChild("footR", ModelPartBuilder.create()
                .uv(131, 65).cuboid(-5f, 0f, -8f, 10f, 4f, 13f),
                ModelTransform.pivot(0f, 26f, 0f));
        ModelPartData d_legL = root.addChild("legL", ModelPartBuilder.create()
                .uv(98, 0).cuboid(-4.5f, 0f, -4.5f, 9f, 26f, 9f)
                .uv(54, 84).cuboid(-5f, 5f, -5f, 10f, 4f, 10f)
                .uv(181, 84).cuboid(-5f, 14f, -5f, 10f, 3f, 10f),
                ModelTransform.pivot(7f, -6f, 0f));
        ModelPartData d_footL = d_legL.addChild("footL", ModelPartBuilder.create()
                .uv(178, 65).cuboid(-5f, 0f, -8f, 10f, 4f, 13f),
                ModelTransform.pivot(0f, 26f, 0f));
        ModelPartData d_body = root.addChild("body", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-9f, -26f, -6f, 18f, 26f, 12f)
                .uv(0, 65).cuboid(-7f, -21f, -8f, 14f, 16f, 2f)
                .uv(36, 114).cuboid(-2f, -15f, -9f, 4f, 4f, 1f)
                .uv(194, 39).cuboid(-6f, -21f, -9f, 1f, 18f, 1f)
                .uv(99, 39).cuboid(5f, -21f, -9f, 1f, 20f, 1f),
                ModelTransform.pivot(0f, -6f, 0f));
        ModelPartData d_spikeBack1 = d_body.addChild("spikeBack1", ModelPartBuilder.create()
                .uv(199, 39).cuboid(-1.5f, -16f, -1.5f, 3f, 16f, 3f),
                ModelTransform.of(-6f, -18f, 6f, -0.5f, 0f, -0.2f));
        ModelPartData d_spikeBack2 = d_body.addChild("spikeBack2", ModelPartBuilder.create()
                .uv(41, 39).cuboid(-2f, -20f, -2f, 4f, 20f, 4f),
                ModelTransform.of(0f, -22f, 6f, -0.6f, 0f, 0f));
        ModelPartData d_spikeBack3 = d_body.addChild("spikeBack3", ModelPartBuilder.create()
                .uv(212, 39).cuboid(-1.5f, -16f, -1.5f, 3f, 16f, 3f),
                ModelTransform.of(6f, -18f, 6f, -0.5f, 0f, 0.2f));
        ModelPartData d_head = d_body.addChild("head", ModelPartBuilder.create()
                .uv(58, 39).cuboid(-5f, -14f, -5f, 10f, 14f, 10f)
                .uv(95, 84).cuboid(-5.5f, -15f, -5.5f, 11f, 3f, 11f)
                .uv(47, 114).cuboid(2.5f, -18f, -1f, 2f, 3f, 2f)
                .uv(209, 100).cuboid(1f, -20f, -2.5f, 5f, 2f, 5f)
                .uv(108, 100).cuboid(-4f, 0f, -4f, 8f, 3f, 8f),
                ModelTransform.pivot(0f, -26f, 0f));
        ModelPartData d_antlerR = d_head.addChild("antlerR", ModelPartBuilder.create()
                .uv(225, 65).cuboid(-1f, -14f, -1f, 2f, 14f, 2f),
                ModelTransform.of(-4f, 43f, 0f, 0f, 0f, -0.5f));
        ModelPartData d_tineR = d_antlerR.addChild("tineR", ModelPartBuilder.create()
                .uv(90, 100).cuboid(-1f, -10f, -1f, 2f, 10f, 2f),
                ModelTransform.of(0f, -8f, 0f, 0f, 0f, -0.9f));
        ModelPartData d_armR = d_body.addChild("armR", ModelPartBuilder.create()
                .uv(135, 0).cuboid(-4.5f, 0f, -4.5f, 9f, 17f, 9f)
                .uv(33, 65).cuboid(-6f, -2f, -6f, 12f, 6f, 12f)
                .uv(56, 114).cuboid(-1f, -5f, -1f, 2f, 3f, 2f)
                .uv(141, 100).cuboid(-3f, -7f, -3f, 6f, 2f, 6f),
                ModelTransform.of(-13f, -22f, 0f, 0f, 0f, 0.12f));
        ModelPartData d_forearmR = d_armR.addChild("forearmR", ModelPartBuilder.create()
                .uv(209, 0).cuboid(-5f, 0f, -5f, 10f, 15f, 10f)
                .uv(0, 100).cuboid(-5.5f, 7f, -5.5f, 11f, 2f, 11f),
                ModelTransform.pivot(0f, 17f, 0f));
        ModelPartData d_handR = d_forearmR.addChild("handR", ModelPartBuilder.create()
                .uv(104, 39).cuboid(-5.5f, 0f, -5.5f, 11f, 9f, 11f)
                .uv(230, 100).cuboid(-5f, 9f, -6f, 2f, 5f, 2f)
                .uv(166, 100).cuboid(-1f, 9f, -6f, 2f, 6f, 2f)
                .uv(239, 100).cuboid(3f, 9f, -6f, 2f, 5f, 2f)
                .uv(18, 114).cuboid(-1f, 9f, 4f, 2f, 4f, 2f),
                ModelTransform.pivot(0f, 15f, 0f));
        ModelPartData d_thornR = d_body.addChild("thornR", ModelPartBuilder.create()
                .uv(243, 65).cuboid(-1.5f, -12f, -1.5f, 3f, 12f, 3f),
                ModelTransform.of(-16f, -24f, 0f, 0f, 0f, -0.9f));
        ModelPartData d_antlerL = d_head.addChild("antlerL", ModelPartBuilder.create()
                .uv(234, 65).cuboid(-1f, -14f, -1f, 2f, 14f, 2f),
                ModelTransform.of(4f, 43f, 0f, 0f, 0f, 0.5f));
        ModelPartData d_tineL = d_antlerL.addChild("tineL", ModelPartBuilder.create()
                .uv(99, 100).cuboid(-1f, -10f, -1f, 2f, 10f, 2f),
                ModelTransform.of(0f, -8f, 0f, 0f, 0f, 0.9f));
        ModelPartData d_armL = d_body.addChild("armL", ModelPartBuilder.create()
                .uv(172, 0).cuboid(-4.5f, 0f, -4.5f, 9f, 17f, 9f)
                .uv(82, 65).cuboid(-6f, -2f, -6f, 12f, 6f, 12f)
                .uv(65, 114).cuboid(-1f, -5f, -1f, 2f, 3f, 2f)
                .uv(175, 100).cuboid(-3f, -7f, -3f, 6f, 2f, 6f),
                ModelTransform.of(13f, -22f, 0f, 0f, 0f, -0.12f));
        ModelPartData d_forearmL = d_armL.addChild("forearmL", ModelPartBuilder.create()
                .uv(0, 39).cuboid(-5f, 0f, -5f, 10f, 15f, 10f)
                .uv(45, 100).cuboid(-5.5f, 7f, -5.5f, 11f, 2f, 11f),
                ModelTransform.pivot(0f, 17f, 0f));
        ModelPartData d_handL = d_forearmL.addChild("handL", ModelPartBuilder.create()
                .uv(149, 39).cuboid(-5.5f, 0f, -5.5f, 11f, 9f, 11f)
                .uv(0, 114).cuboid(-5f, 9f, -6f, 2f, 5f, 2f)
                .uv(200, 100).cuboid(-1f, 9f, -6f, 2f, 6f, 2f)
                .uv(9, 114).cuboid(3f, 9f, -6f, 2f, 5f, 2f)
                .uv(27, 114).cuboid(-1f, 9f, 4f, 2f, 4f, 2f),
                ModelTransform.pivot(0f, 15f, 0f));
        ModelPartData d_thornL = d_body.addChild("thornL", ModelPartBuilder.create()
                .uv(0, 84).cuboid(-1.5f, -12f, -1.5f, 3f, 12f, 3f),
                ModelTransform.of(16f, -24f, 0f, 0f, 0f, 0.9f));
        return TexturedModelData.of(data, 256, 256);
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }

    @Override
    public void setAngles(ForestForgottenEntity e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        this.getPart().traverse().forEach(ModelPart::resetTransform);
        float swing = limbAngle * 0.5f;
        float amp = Math.min(limbDistance, 1.0f);
        this.legR.pitch += MathHelper.cos(swing) * 1.0f * amp;
        this.legL.pitch += MathHelper.cos(swing + MathHelper.PI) * 1.0f * amp;
        this.armR.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.6f * amp;
        this.armL.pitch += MathHelper.cos(swing) * 0.6f * amp;
        this.body.roll += MathHelper.cos(swing) * 0.05f * amp;
        float breathe = MathHelper.sin(anim * 0.07f);
        this.armR.roll += 0.03f * breathe;
        this.armL.roll -= 0.03f * breathe;
        this.forearmR.pitch += -0.15f + 0.05f * breathe;
        this.forearmL.pitch += -0.15f + 0.05f * breathe;
        this.head.yaw += headYaw * 0.017453292f * 0.7f;
        this.head.pitch += headPitch * 0.017453292f * 0.7f;
        if (e.isCasting()) {
            this.armR.pitch += -2.5f + MathHelper.sin(anim * 0.4f) * 0.1f;
            this.armL.pitch += -2.5f - MathHelper.sin(anim * 0.4f) * 0.1f;
            this.head.pitch += -0.35f;
        } else if (e.isAttacking()) {
            float s = MathHelper.sin(anim * 0.45f);
            this.armR.pitch += -1.4f + s * 0.7f;
            this.armL.pitch += -1.4f - s * 0.7f;
        }
    }
}
