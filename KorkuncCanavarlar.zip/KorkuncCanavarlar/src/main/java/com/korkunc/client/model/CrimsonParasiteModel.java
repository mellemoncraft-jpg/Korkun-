package com.korkunc.client.model;

import com.korkunc.entity.CrimsonParasiteEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** OTOMATİK ÜRETİLDİ (tools/generate_assets.py). Elle düzenleme; betiği düzenle. */
public class CrimsonParasiteModel extends SinglePartEntityModel<CrimsonParasiteEntity> {
    private final ModelPart root;
    private final ModelPart pelvis;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart jaw;
    private final ModelPart armR;
    private final ModelPart forearmR;
    private final ModelPart armL;
    private final ModelPart forearmL;
    private final ModelPart pipeR;
    private final ModelPart legR;
    private final ModelPart shinR;
    private final ModelPart footR;
    private final ModelPart spR1;
    private final ModelPart spR1b;
    private final ModelPart spR2;
    private final ModelPart spR2b;
    private final ModelPart tentR;
    private final ModelPart tentR2;
    private final ModelPart pipeL;
    private final ModelPart legL;
    private final ModelPart shinL;
    private final ModelPart footL;
    private final ModelPart spL1;
    private final ModelPart spL1b;
    private final ModelPart spL2;
    private final ModelPart spL2b;
    private final ModelPart tentL;
    private final ModelPart tentL2;
    public CrimsonParasiteModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.torso = this.pelvis.getChild("torso");
        this.head = this.torso.getChild("head");
        this.jaw = this.head.getChild("jaw");
        this.armR = this.torso.getChild("armR");
        this.forearmR = this.armR.getChild("forearmR");
        this.armL = this.torso.getChild("armL");
        this.forearmL = this.armL.getChild("forearmL");
        this.pipeR = this.torso.getChild("pipeR");
        this.legR = this.pelvis.getChild("legR");
        this.shinR = this.legR.getChild("shinR");
        this.footR = this.shinR.getChild("footR");
        this.spR1 = this.torso.getChild("spR1");
        this.spR1b = this.spR1.getChild("spR1b");
        this.spR2 = this.torso.getChild("spR2");
        this.spR2b = this.spR2.getChild("spR2b");
        this.tentR = this.torso.getChild("tentR");
        this.tentR2 = this.tentR.getChild("tentR2");
        this.pipeL = this.torso.getChild("pipeL");
        this.legL = this.pelvis.getChild("legL");
        this.shinL = this.legL.getChild("shinL");
        this.footL = this.shinL.getChild("footL");
        this.spL1 = this.torso.getChild("spL1");
        this.spL1b = this.spL1.getChild("spL1b");
        this.spL2 = this.torso.getChild("spL2");
        this.spL2b = this.spL2.getChild("spL2b");
        this.tentL = this.torso.getChild("tentL");
        this.tentL2 = this.tentL.getChild("tentL2");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData d_pelvis = root.addChild("pelvis", ModelPartBuilder.create()
                .uv(36, 62).cuboid(-4f, -4f, -3f, 8f, 4f, 6f)
                .uv(0, 96).cuboid(-3f, 0f, -2.5f, 6f, 3f, 5f),
                ModelTransform.pivot(0f, 2f, 0f));
        ModelPartData d_torso = d_pelvis.addChild("torso", ModelPartBuilder.create()
                .uv(36, 0).cuboid(-5f, -16f, -3f, 10f, 16f, 6f)
                .uv(25, 75).cuboid(-5.5f, -5f, -3.5f, 11f, 2f, 7f)
                .uv(62, 75).cuboid(-5.5f, -9f, -3.5f, 11f, 2f, 7f)
                .uv(0, 86).cuboid(-5.5f, -13f, -3.5f, 11f, 2f, 7f)
                .uv(90, 0).cuboid(-1f, -16f, 3f, 2f, 16f, 2f)
                .uv(62, 47).cuboid(-4f, -14f, 4f, 3f, 10f, 3f)
                .uv(75, 47).cuboid(1f, -14f, 4f, 3f, 10f, 3f)
                .uv(65, 105).cuboid(-2f, -10f, -4f, 4f, 4f, 1f),
                ModelTransform.of(0f, -4f, 0f, 0.25f, 0f, 0f));
        ModelPartData d_head = d_torso.addChild("head", ModelPartBuilder.create()
                .uv(0, 30).cuboid(-4f, -8f, -4f, 8f, 8f, 8f)
                .uv(88, 47).cuboid(-4.5f, -8f, -4.5f, 9f, 3f, 9f)
                .uv(76, 105).cuboid(-0.5f, -11f, -0.5f, 1f, 3f, 1f)
                .uv(97, 96).cuboid(-1.5f, 0f, -1.5f, 3f, 3f, 3f),
                ModelTransform.of(0f, -16f, 0f, -0.25f, 0f, 0f));
        ModelPartData d_jaw = d_head.addChild("jaw", ModelPartBuilder.create()
                .uv(37, 86).cuboid(-3f, 0f, -3.5f, 6f, 3f, 6f),
                ModelTransform.pivot(0f, -0.5f, -0.5f));
        ModelPartData d_armR = d_torso.addChild("armR", ModelPartBuilder.create()
                .uv(68, 30).cuboid(-1.5f, 0f, -1.5f, 3f, 12f, 3f)
                .uv(65, 62).cuboid(-3f, -2f, -3f, 6f, 4f, 6f),
                ModelTransform.of(-6.5f, -14f, 0f, 0f, 0f, 0.15f));
        ModelPartData d_forearmR = d_armR.addChild("forearmR", ModelPartBuilder.create()
                .uv(33, 30).cuboid(-2f, 0f, -2f, 4f, 12f, 4f)
                .uv(62, 86).cuboid(-2.5f, 3f, -2.5f, 5f, 4f, 5f)
                .uv(87, 96).cuboid(-2f, 12f, -2f, 1f, 6f, 1f)
                .uv(23, 96).cuboid(-0.5f, 12f, -2f, 1f, 7f, 1f)
                .uv(92, 96).cuboid(1f, 12f, -2f, 1f, 6f, 1f)
                .uv(110, 96).cuboid(-0.5f, 12f, 1f, 1f, 5f, 1f),
                ModelTransform.pivot(0f, 12f, 0f));
        ModelPartData d_armL = d_torso.addChild("armL", ModelPartBuilder.create()
                .uv(81, 30).cuboid(-1.5f, 0f, -1.5f, 3f, 12f, 3f)
                .uv(90, 62).cuboid(-3f, -2f, -3f, 6f, 4f, 6f),
                ModelTransform.of(6.5f, -14f, 0f, 0f, 0f, -0.15f));
        ModelPartData d_forearmL = d_armL.addChild("forearmL", ModelPartBuilder.create()
                .uv(69, 0).cuboid(-2.5f, 0f, -2.5f, 5f, 14f, 5f)
                .uv(0, 75).cuboid(-3f, 14f, -3f, 6f, 4f, 6f)
                .uv(28, 96).cuboid(-3f, 7f, -3f, 6f, 2f, 6f),
                ModelTransform.pivot(0f, 12f, 0f));
        ModelPartData d_pipeR = d_torso.addChild("pipeR", ModelPartBuilder.create()
                .uv(94, 30).cuboid(-1.5f, -12f, -1.5f, 3f, 12f, 3f),
                ModelTransform.of(-6f, -14f, 3f, -0.2f, 0f, -0.5f));
        ModelPartData d_legR = d_pelvis.addChild("legR", ModelPartBuilder.create()
                .uv(0, 47).cuboid(-1.5f, 0f, -1.5f, 3f, 11f, 3f)
                .uv(53, 96).cuboid(-2f, 0f, -2f, 4f, 4f, 4f),
                ModelTransform.of(-3f, 0f, 0f, -0.6f, 0f, 0f));
        ModelPartData d_shinR = d_legR.addChild("shinR", ModelPartBuilder.create()
                .uv(50, 30).cuboid(-1f, 0f, -1f, 2f, 14f, 2f)
                .uv(115, 96).cuboid(-1.5f, 5f, -1.5f, 3f, 3f, 3f),
                ModelTransform.of(0f, 11f, 0f, 1.2f, 0f, 0f));
        ModelPartData d_footR = d_shinR.addChild("footR", ModelPartBuilder.create()
                .uv(83, 86).cuboid(-1.5f, -1f, -6f, 3f, 2f, 7f),
                ModelTransform.of(0f, 14f, 0f, -0.6f, 0f, 0f));
        ModelPartData d_spR1 = d_torso.addChild("spR1", ModelPartBuilder.create()
                .uv(0, 62).cuboid(-1f, 0f, -1f, 2f, 10f, 2f),
                ModelTransform.of(-5f, -7f, -2.5f, 0f, 0f, 1.1f));
        ModelPartData d_spR1b = d_spR1.addChild("spR1b", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-1f, 0f, -1f, 2f, 27f, 2f)
                .uv(0, 105).cuboid(-1.5f, 3f, -1.5f, 3f, 3f, 3f),
                ModelTransform.of(0f, 10f, 0f, 0f, 0f, -1.2f));
        ModelPartData d_spR2 = d_torso.addChild("spR2", ModelPartBuilder.create()
                .uv(9, 62).cuboid(-1f, 0f, -1f, 2f, 10f, 2f),
                ModelTransform.of(-5f, -5.5f, 2.5f, 0f, 0f, 1.1f));
        ModelPartData d_spR2b = d_spR2.addChild("spR2b", ModelPartBuilder.create()
                .uv(9, 0).cuboid(-1f, 0f, -1f, 2f, 27f, 2f)
                .uv(13, 105).cuboid(-1.5f, 3f, -1.5f, 3f, 3f, 3f),
                ModelTransform.of(0f, 10f, 0f, 0f, 0f, -1.2f));
        ModelPartData d_tentR = d_torso.addChild("tentR", ModelPartBuilder.create()
                .uv(13, 47).cuboid(-1f, 0f, -1f, 2f, 12f, 2f),
                ModelTransform.of(-3f, -10f, -3f, -0.4f, 0f, 0.2f));
        ModelPartData d_tentR2 = d_tentR.addChild("tentR2", ModelPartBuilder.create()
                .uv(22, 47).cuboid(-1f, 0f, -1f, 2f, 12f, 2f),
                ModelTransform.pivot(0f, 12f, 0f));
        ModelPartData d_pipeL = d_torso.addChild("pipeL", ModelPartBuilder.create()
                .uv(107, 30).cuboid(-1.5f, -12f, -1.5f, 3f, 12f, 3f),
                ModelTransform.of(6f, -14f, 3f, -0.2f, 0f, 0.5f));
        ModelPartData d_legL = d_pelvis.addChild("legL", ModelPartBuilder.create()
                .uv(31, 47).cuboid(-1.5f, 0f, -1.5f, 3f, 11f, 3f)
                .uv(70, 96).cuboid(-2f, 0f, -2f, 4f, 4f, 4f),
                ModelTransform.of(3f, 0f, 0f, -0.6f, 0f, 0f));
        ModelPartData d_shinL = d_legL.addChild("shinL", ModelPartBuilder.create()
                .uv(59, 30).cuboid(-1f, 0f, -1f, 2f, 14f, 2f)
                .uv(26, 105).cuboid(-1.5f, 5f, -1.5f, 3f, 3f, 3f),
                ModelTransform.of(0f, 11f, 0f, 1.2f, 0f, 0f));
        ModelPartData d_footL = d_shinL.addChild("footL", ModelPartBuilder.create()
                .uv(104, 86).cuboid(-1.5f, -1f, -6f, 3f, 2f, 7f),
                ModelTransform.of(0f, 14f, 0f, -0.6f, 0f, 0f));
        ModelPartData d_spL1 = d_torso.addChild("spL1", ModelPartBuilder.create()
                .uv(18, 62).cuboid(-1f, 0f, -1f, 2f, 10f, 2f),
                ModelTransform.of(5f, -7f, -2.5f, 0f, 0f, -1.1f));
        ModelPartData d_spL1b = d_spL1.addChild("spL1b", ModelPartBuilder.create()
                .uv(18, 0).cuboid(-1f, 0f, -1f, 2f, 27f, 2f)
                .uv(39, 105).cuboid(-1.5f, 3f, -1.5f, 3f, 3f, 3f),
                ModelTransform.of(0f, 10f, 0f, 0f, 0f, 1.2f));
        ModelPartData d_spL2 = d_torso.addChild("spL2", ModelPartBuilder.create()
                .uv(27, 62).cuboid(-1f, 0f, -1f, 2f, 10f, 2f),
                ModelTransform.of(5f, -5.5f, 2.5f, 0f, 0f, -1.1f));
        ModelPartData d_spL2b = d_spL2.addChild("spL2b", ModelPartBuilder.create()
                .uv(27, 0).cuboid(-1f, 0f, -1f, 2f, 27f, 2f)
                .uv(52, 105).cuboid(-1.5f, 3f, -1.5f, 3f, 3f, 3f),
                ModelTransform.of(0f, 10f, 0f, 0f, 0f, 1.2f));
        ModelPartData d_tentL = d_torso.addChild("tentL", ModelPartBuilder.create()
                .uv(44, 47).cuboid(-1f, 0f, -1f, 2f, 12f, 2f),
                ModelTransform.of(3f, -10f, -3f, -0.4f, 0f, -0.2f));
        ModelPartData d_tentL2 = d_tentL.addChild("tentL2", ModelPartBuilder.create()
                .uv(53, 47).cuboid(-1f, 0f, -1f, 2f, 12f, 2f),
                ModelTransform.pivot(0f, 12f, 0f));
        return TexturedModelData.of(data, 128, 128);
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }

    @Override
    public void setAngles(CrimsonParasiteEntity e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        this.getPart().traverse().forEach(ModelPart::resetTransform);
        float swing = limbAngle * 0.8f;
        float amp = Math.min(limbDistance, 1.0f);
        this.legR.pitch += MathHelper.cos(swing) * 0.9f * amp;
        this.legL.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.9f * amp;
        this.armR.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.6f * amp;
        this.armL.pitch += MathHelper.cos(swing) * 0.4f * amp;
        this.spR1.pitch += MathHelper.cos(swing) * 0.5f * amp;
        this.spL2.pitch += MathHelper.cos(swing) * 0.5f * amp;
        this.spL1.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.5f * amp;
        this.spR2.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.5f * amp;
        float idle = MathHelper.sin(anim * 0.1f);
        this.torso.pitch += 0.03f * idle + amp * 0.1f;
        this.tentR.pitch += 0.25f * idle;
        this.tentR2.pitch += 0.4f * MathHelper.sin(anim * 0.1f - 0.9f);
        this.tentL.pitch -= 0.25f * idle;
        this.tentL2.pitch += 0.4f * MathHelper.sin(anim * 0.1f - 0.9f + MathHelper.PI);
        this.jaw.pitch += 0.12f + 0.06f * MathHelper.sin(anim * 0.25f);
        this.head.yaw += headYaw * 0.017453292f * 0.8f;
        this.head.pitch += headPitch * 0.017453292f * 0.8f;
        if (e.isCasting()) {
            this.armR.pitch += -2.0f;
            this.armL.pitch += -1.55f;
            this.jaw.pitch += 0.7f;
            this.head.pitch += -0.2f;
        } else if (e.isAttacking()) {
            this.armR.pitch += -1.3f + MathHelper.sin(anim * 0.5f) * 0.8f;
            this.armL.pitch += -0.6f;
            this.jaw.pitch += 0.4f;
        }
    }
}
