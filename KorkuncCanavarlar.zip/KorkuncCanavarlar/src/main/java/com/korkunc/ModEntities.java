package com.korkunc;

import com.korkunc.entity.CrimsonParasiteEntity;
import com.korkunc.entity.ForestForgottenEntity;
import com.korkunc.entity.SculkShadowEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<ForestForgottenEntity> FOREST_FORGOTTEN = register("forest_forgotten",
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ForestForgottenEntity::new)
                    .dimensions(EntityDimensions.fixed(1.9f, 4.4f)).trackRangeBlocks(96).build());

    public static final EntityType<CrimsonParasiteEntity> CRIMSON_PARASITE = register("crimson_parasite",
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, CrimsonParasiteEntity::new)
                    .dimensions(EntityDimensions.fixed(1.3f, 3.0f)).trackRangeBlocks(96).build());

    public static final EntityType<SculkShadowEntity> SCULK_SHADOW = register("sculk_shadow",
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, SculkShadowEntity::new)
                    .dimensions(EntityDimensions.fixed(1.2f, 3.7f)).trackRangeBlocks(96).fireImmune().build());

    private static <T extends Entity> EntityType<T> register(String name, EntityType<T> type) {
        return Registry.register(Registries.ENTITY_TYPE, new Identifier(KorkuncMod.MOD_ID, name), type);
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(FOREST_FORGOTTEN, ForestForgottenEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(CRIMSON_PARASITE, CrimsonParasiteEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(SCULK_SHADOW, SculkShadowEntity.createAttributes());
    }
}
