package com.korkunc;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KorkuncMod implements ModInitializer {
    public static final String MOD_ID = "korkunc";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
        LOGGER.info("Korkunç Canavarlar yüklendi!");
    }
}
