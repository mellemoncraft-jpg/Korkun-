package com.korkunc.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import java.util.UUID;

/**
 * KIZIL PARAZİT - makine/et melezi iskelet.
 * Yetenekler: Kan Emme (vuruşta can çalar + açlık), Atılma (zıplayıp üstüne atlar),
 * Dokunaç Kancası (uzaktaki oyuncuyu kendine çeker), Parazit Sürüsü (gümüş balığı yavruları).
 * 2. Faz "Kızıl Öfke": Hız II + Güç, Kan Nabzı (yakındakilerden can emer), Wither vuruşu.
 * Bağışıklık: zehir.
 */
public class CrimsonParasiteEntity extends BaseBossEntity {
    private static final UUID DAMAGE_ID = UUID.fromString("0f6b7d52-93a1-4e8c-b2d4-5a6c7e8f9012");

    private int leapCd = 100;
    private int grabCd = 180;
    private int swarmCd = 260;
    private int pulseCd = 200;
    private int leapTicks;

    public CrimsonParasiteEntity(EntityType<? extends CrimsonParasiteEntity> type, World world) {
        super(type, world, BossBar.Color.RED, BossBar.Color.YELLOW);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 260.0)
                .add(EntityAttributes.GENERIC_ARMOR, 6.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.6)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void tickAbilities() {
        boolean p2 = this.isPhaseTwo();
        if (this.leapCd > 0) this.leapCd--;
        if (this.grabCd > 0) this.grabCd--;
        if (this.swarmCd > 0) this.swarmCd--;
        if (this.pulseCd > 0) this.pulseCd--;

        if (p2 && this.age % 40 == 0) {
            this.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 100, 1, false, false));
        }

        LivingEntity target = this.getTarget();

        // Atılma sırasında temas
        if (this.leapTicks > 0) {
            this.leapTicks--;
            if (target != null && this.distanceTo(target) < 2.6f) {
                this.tryAttack(target);
                this.leapTicks = 0;
            }
        }

        if (target == null || !target.isAlive() || this.isBusy()) {
            return;
        }
        double d = this.distanceTo(target);
        if (p2 && this.pulseCd == 0 && d <= 9) {
            this.pulseCd = 200;
            this.startCast(25, SoundEvents.ENTITY_WARDEN_HEARTBEAT, this::bloodPulse);
        } else if (this.swarmCd == 0 && d <= 30) {
            this.swarmCd = p2 ? 240 : 320;
            this.startCast(20, SoundEvents.ENTITY_SPIDER_AMBIENT, this::swarm);
        } else if (this.grabCd == 0 && d >= 7 && d <= 22 && this.canSee(target)) {
            this.grabCd = p2 ? 120 : 180;
            this.startCast(15, SoundEvents.ENTITY_FISHING_BOBBER_RETRIEVE, () -> this.grab(target));
        } else if (this.leapCd == 0 && d >= 5 && d <= 16 && this.isOnGround()) {
            this.leapCd = p2 ? 60 : 90;
            this.startCast(12, SoundEvents.ENTITY_RAVAGER_ROAR, () -> this.leap(target));
        }
    }

    private void leap(LivingEntity t) {
        Vec3d dir = t.getPos().subtract(this.getPos());
        double len = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        if (len < 0.1) return;
        double speed = MathHelper.clamp(len * 0.07, 0.5, 1.3);
        this.setVelocity(dir.x / len * speed, 0.7, dir.z / len * speed);
        this.velocityDirty = true;
        this.leapTicks = 20;
    }

    private void grab(LivingEntity t) {
        if (!t.isAlive()) return;
        ServerWorld w = (ServerWorld) this.getWorld();
        Vec3d from = this.getEyePos();
        Vec3d to = t.getEyePos();
        int steps = Math.max(1, (int) from.distanceTo(to));
        for (int i = 0; i <= steps; i++) {
            Vec3d p = from.lerp(to, i / (double) steps);
            w.spawnParticles(DustParticleEffect.DEFAULT, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0.0);
            w.spawnParticles(ParticleTypes.CRIMSON_SPORE, p.x, p.y, p.z, 1, 0.1, 0.1, 0.1, 0.0);
        }
        Vec3d pull = this.getPos().subtract(t.getPos());
        Vec3d n = pull.normalize();
        double strength = Math.min(2.0, 0.6 + pull.length() * 0.09);
        t.damage(this.getDamageSources().mobAttack(this), 7.0f);
        t.setVelocity(n.x * strength, 0.4, n.z * strength);
        t.velocityModified = true;
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 2), this);
    }

    private void swarm() {
        ServerWorld w = (ServerWorld) this.getWorld();
        int existing = w.getEntitiesByClass(SilverfishEntity.class, this.getBoundingBox().expand(24.0), s -> true).size();
        int n = Math.min(this.isPhaseTwo() ? 5 : 3, 10 - existing);
        for (int i = 0; i < n; i++) {
            SilverfishEntity s = EntityType.SILVERFISH.create(w);
            if (s == null) continue;
            double a = this.random.nextDouble() * Math.PI * 2.0;
            s.refreshPositionAndAngles(this.getX() + Math.cos(a) * 2.5, this.getY(), this.getZ() + Math.sin(a) * 2.5,
                    this.random.nextFloat() * 360.0f, 0.0f);
            s.setTarget(this.getTarget());
            s.setCustomName(Text.literal("Parazit Yavrusu"));
            w.spawnEntity(s);
            w.spawnParticles(ParticleTypes.CRIMSON_SPORE, s.getX(), s.getY() + 0.3, s.getZ(), 12, 0.3, 0.3, 0.3, 0.05);
        }
    }

    private void bloodPulse() {
        ServerWorld w = (ServerWorld) this.getWorld();
        for (int ring = 0; ring < 3; ring++) {
            for (int i = 0; i < 28; i++) {
                double a = i * Math.PI / 14.0;
                double r = 2.0 + ring * 3.0;
                w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, this.getX() + Math.cos(a) * r, this.getY() + 0.6,
                        this.getZ() + Math.sin(a) * r, 1, 0, 0.1, 0, 0.0);
            }
        }
        int healed = 0;
        for (PlayerEntity p : this.playersWithin(10.0)) {
            p.damage(this.getDamageSources().indirectMagic(this, this), 8.0f);
            if (healed < 3) {
                this.heal(8.0f);
                healed++;
            }
        }
    }

    /** Kan Emme: vuruş can çalar ve açlık verir. */
    @Override
    public boolean tryAttack(Entity target) {
        boolean ok = super.tryAttack(target);
        if (ok && target instanceof LivingEntity le) {
            this.heal(this.isPhaseTwo() ? 6.0f : 3.0f);
            le.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 120, 1), this);
            if (this.isPhaseTwo()) {
                le.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60, 0), this);
            }
            if (this.getWorld() instanceof ServerWorld w) {
                w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, le.getX(), le.getBodyY(0.6), le.getZ(), 6, 0.3, 0.3, 0.3, 0.1);
            }
        }
        return ok;
    }

    @Override
    protected void onPhaseTwo() {
        EntityAttributeInstance atk = this.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (atk != null) {
            atk.removeModifier(DAMAGE_ID);
            atk.addPersistentModifier(new EntityAttributeModifier(DAMAGE_ID, "Kizil Ofke", 5.0, EntityAttributeModifier.Operation.ADDITION));
        }
        this.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 100, 1, false, false));
        this.playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 3.0f, 0.6f);
    }

    @Override
    public boolean canHaveStatusEffect(StatusEffectInstance effect) {
        if (effect.getEffectType() == StatusEffects.POISON) {
            return false;
        }
        return super.canHaveStatusEffect(effect);
    }

    @Override
    protected ParticleEffect castParticle() {
        return ParticleTypes.CRIMSON_SPORE;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_RAVAGER_DEATH;
    }
}
