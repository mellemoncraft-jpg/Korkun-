package com.korkunc.entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.block.Blocks;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * ORMAN UNUTULANI - ağaç golem.
 * Yetenekler: Kök Patlaması (işaretli bölgelerde yerden kök fırlar), Spor Bulutu (zehirli bulut),
 * Yer Sarsıntısı (yakın dövüş AoE), Gün Işığında Yenilenme.
 * Zayıflık: ateş (x1.6) ve baltalar (x1.3). Zehir/Wither bağışık.
 * 2. Faz: +8 zırh, +6 saldırı, daha sık yetenek, 2x güneş yenilenmesi, 7 ekstra kök.
 */
public class ForestForgottenEntity extends BaseBossEntity {
    private static final UUID ARMOR_ID = UUID.fromString("5a7f2c1e-8d63-4f0a-9b11-2c4e6f8a0b13");
    private static final UUID DAMAGE_ID = UUID.fromString("c3d1e9a4-27b5-4c68-8e0f-71a2b3c4d5e6");

    private static final class Eruption {
        final double x, y, z;
        int delay;

        Eruption(double x, double y, double z, int delay) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.delay = delay;
        }
    }

    private final List<Eruption> eruptions = new ArrayList<>();
    private int rootCd = 80;
    private int sporeCd = 160;
    private int slamCd = 100;

    public ForestForgottenEntity(EntityType<? extends ForestForgottenEntity> type, World world) {
        super(type, world, BossBar.Color.GREEN, BossBar.Color.RED);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 320.0)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void tickAbilities() {
        ServerWorld w = (ServerWorld) this.getWorld();
        this.tickEruptions(w);

        // Gün ışığında yenilenme
        if (this.age % 20 == 0 && w.isDay() && w.isSkyVisible(this.getBlockPos()) && this.getHealth() < this.getMaxHealth()) {
            this.heal(this.isPhaseTwo() ? 3.0f : 1.0f);
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, this.getX(), this.getBodyY(0.6), this.getZ(), 6, 0.8, 1.2, 0.8, 0.0);
        }

        if (this.rootCd > 0) this.rootCd--;
        if (this.sporeCd > 0) this.sporeCd--;
        if (this.slamCd > 0) this.slamCd--;

        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive() || this.isBusy()) {
            return;
        }
        double dist = this.distanceTo(target);
        boolean p2 = this.isPhaseTwo();
        if (this.slamCd == 0 && dist <= 6.5) {
            this.slamCd = p2 ? 110 : 170;
            this.startCast(22, SoundEvents.ENTITY_RAVAGER_ROAR, this::slam);
        } else if (this.rootCd == 0 && dist <= 26 && this.canSee(target)) {
            this.rootCd = p2 ? 70 : 110;
            this.startCast(18, SoundEvents.BLOCK_ROOTS_BREAK, () -> this.rootBurst(target));
        } else if (this.sporeCd == 0 && dist <= 32) {
            this.sporeCd = p2 ? 180 : 260;
            this.startCast(14, SoundEvents.BLOCK_SPORE_BLOSSOM_BREAK, () -> this.sporeCloud(target));
        }
    }

    // ---- Yer Sarsıntısı
    private void slam() {
        ServerWorld w = (ServerWorld) this.getWorld();
        this.playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 1.5f, 0.6f);
        w.spawnParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 0.2, this.getZ(), 8, 2.5, 0.2, 2.5, 0.0);
        w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.PODZOL.getDefaultState()),
                this.getX(), this.getY() + 0.3, this.getZ(), 80, 3.0, 0.2, 3.0, 0.2);
        Box area = this.getBoundingBox().expand(7.0, 2.0, 7.0);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, area, this::isValidVictim)) {
            if (e.squaredDistanceTo(this) > 49.0) continue;
            e.damage(this.getDamageSources().mobAttack(this), this.isPhaseTwo() ? 22.0f : 16.0f);
            Vec3d away = e.getPos().subtract(this.getPos()).normalize();
            e.setVelocity(away.x * 1.1, 0.7, away.z * 1.1);
            e.velocityModified = true;
        }
    }

    // ---- Kök Patlaması
    private void rootBurst(LivingEntity target) {
        if (!target.isAlive()) return;
        this.addEruption(target.getX(), target.getY(), target.getZ(), 26);
        int extra = this.isPhaseTwo() ? 7 : 3;
        for (int i = 0; i < extra; i++) {
            double a = this.random.nextDouble() * Math.PI * 2.0;
            double r = 2.0 + this.random.nextDouble() * 4.0;
            this.addEruption(target.getX() + Math.cos(a) * r, target.getY(), target.getZ() + Math.sin(a) * r, 26 + i * 3);
        }
    }

    private void addEruption(double x, double y, double z, int delay) {
        this.eruptions.add(new Eruption(x, y, z, delay));
    }

    private void tickEruptions(ServerWorld w) {
        Iterator<Eruption> it = this.eruptions.iterator();
        while (it.hasNext()) {
            Eruption e = it.next();
            e.delay--;
            if (e.delay % 2 == 0) {
                w.spawnParticles(ParticleTypes.COMPOSTER, e.x, e.y + 0.1, e.z, 4, 1.0, 0.05, 1.0, 0.0);
            }
            if (e.delay <= 0) {
                this.erupt(w, e);
                it.remove();
            }
        }
    }

    private void erupt(ServerWorld w, Eruption e) {
        w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.DARK_OAK_LOG.getDefaultState()),
                e.x, e.y + 1.0, e.z, 40, 0.8, 1.2, 0.8, 0.15);
        w.playSound(null, BlockPos.ofFloored(e.x, e.y, e.z), SoundEvents.BLOCK_WOOD_BREAK, SoundCategory.HOSTILE, 1.5f, 0.6f);
        Box box = new Box(e.x - 1.4, e.y - 1.0, e.z - 1.4, e.x + 1.4, e.y + 3.0, e.z + 1.4);
        for (LivingEntity v : w.getEntitiesByClass(LivingEntity.class, box, this::isValidVictim)) {
            v.damage(this.getDamageSources().mobAttack(this), 13.0f);
            v.addVelocity(0.0, 0.85, 0.0);
            v.velocityModified = true;
            v.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1), this);
        }
    }

    // ---- Spor Bulutu
    private void sporeCloud(LivingEntity target) {
        if (!target.isAlive()) return;
        AreaEffectCloudEntity c = new AreaEffectCloudEntity(this.getWorld(), target.getX(), target.getY(), target.getZ());
        c.setOwner(this);
        c.setRadius(4.5f);
        c.setDuration(160);
        c.setParticleType(ParticleTypes.SPORE_BLOSSOM_AIR);
        c.addEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1));
        c.addEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 140, 0));
        if (this.isPhaseTwo()) {
            c.addEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 140, 1));
        }
        this.getWorld().spawnEntity(c);
    }

    // ---- 2. Faz
    @Override
    protected void onPhaseTwo() {
        EntityAttributeInstance armor = this.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        if (armor != null) {
            armor.removeModifier(ARMOR_ID);
            armor.addPersistentModifier(new EntityAttributeModifier(ARMOR_ID, "Kabuk Zirhi", 8.0, EntityAttributeModifier.Operation.ADDITION));
        }
        EntityAttributeInstance atk = this.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (atk != null) {
            atk.removeModifier(DAMAGE_ID);
            atk.addPersistentModifier(new EntityAttributeModifier(DAMAGE_ID, "Dogan Gazabi", 6.0, EntityAttributeModifier.Operation.ADDITION));
        }
        this.playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 3.0f, 0.5f);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isIn(DamageTypeTags.IS_FIRE)) {
            amount *= 1.6f;
        }
        if (source.getAttacker() instanceof LivingEntity a && a.getMainHandStack().getItem() instanceof AxeItem) {
            amount *= 1.3f;
        }
        return super.damage(source, amount);
    }

    @Override
    public boolean canHaveStatusEffect(StatusEffectInstance effect) {
        if (effect.getEffectType() == StatusEffects.POISON || effect.getEffectType() == StatusEffects.WITHER) {
            return false;
        }
        return super.canHaveStatusEffect(effect);
    }

    @Override
    protected ParticleEffect castParticle() {
        return ParticleTypes.COMPOSTER;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_RAVAGER_DEATH;
    }
}
