package com.korkunc.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.FlyGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import java.util.UUID;

/**
 * SKULK GÖLGESİ - uçan, dört kollu gölge.
 * Pasif: Karanlık Aura (16 blok içindeki oyunculara Karanlık efekti).
 * Yetenekler: Sonik Çığlık (menzilli, zırh yok sayan hasar), Gölge Adımı (hedefin arkasına ışınlanır).
 * 2. Faz: Skulk Çığlığı (geniş alan hasarı + körlük + geri itme), daha hızlı yetenekler.
 * Zayıflık: aydınlık yerde (ışık >= 12) %30 fazla hasar alır. Oklardan %50 az hasar alır.
 * Bağışıklık: düşme, ateş, Karanlık/Körlük/Wither efektleri.
 */
public class SculkShadowEntity extends BaseBossEntity {
    private static final UUID DAMAGE_ID = UUID.fromString("7e2a4c91-5b38-4d06-a1f7-3c9d8e0b6a24");

    private int boltCd = 80;
    private int stepCd = 120;
    private int shriekCd = 160;

    public SculkShadowEntity(EntityType<? extends SculkShadowEntity> type, World world) {
        super(type, world, BossBar.Color.PURPLE, BossBar.Color.RED);
        this.moveControl = new FlightMoveControl(this, 20, true);
        this.setNoGravity(true);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 340.0)
                .add(EntityAttributes.GENERIC_ARMOR, 4.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.6)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        return new BirdNavigation(this, world);
    }

    @Override
    protected Goal createWanderGoal() {
        return new FlyGoal(this, 0.8);
    }

    @Override
    protected void tickAbilities() {
        ServerWorld w = (ServerWorld) this.getWorld();
        if (this.boltCd > 0) this.boltCd--;
        if (this.stepCd > 0) this.stepCd--;
        if (this.shriekCd > 0) this.shriekCd--;

        // Karanlık Aura
        if (this.age % 40 == 0) {
            for (PlayerEntity p : this.playersWithin(16.0)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0, false, false), this);
            }
        }
        if (this.age % 4 == 0) {
            w.spawnParticles(ParticleTypes.SCULK_SOUL, this.getX(), this.getBodyY(0.5), this.getZ(), 1, 0.5, 1.2, 0.5, 0.01);
        }

        LivingEntity t = this.getTarget();
        if (t == null || !t.isAlive() || this.isBusy()) {
            return;
        }
        double d = this.distanceTo(t);
        boolean p2 = this.isPhaseTwo();
        if (p2 && this.shriekCd == 0 && d <= 14) {
            this.shriekCd = 240;
            this.startCast(40, SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, this::shriek);
        } else if (this.stepCd == 0 && d >= 6 && d <= 28) {
            this.stepCd = p2 ? 100 : 150;
            this.startCast(10, SoundEvents.ENTITY_ENDERMAN_TELEPORT, () -> this.shadowStep(t));
        } else if (this.boltCd == 0 && d <= 34 && this.canSee(t)) {
            this.boltCd = p2 ? 60 : 100;
            this.startCast(24, SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, () -> this.sonicBolt(t));
        }
    }

    private void sonicBolt(LivingEntity t) {
        if (!t.isAlive()) return;
        ServerWorld w = (ServerWorld) this.getWorld();
        Vec3d from = this.getEyePos();
        Vec3d dir = t.getEyePos().subtract(from);
        double len = dir.length();
        Vec3d n = dir.normalize();
        for (int i = 1; i <= (int) len; i++) {
            Vec3d p = from.add(n.multiply(i));
            w.spawnParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        this.playSound(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 3.0f, 1.0f);
        t.damage(this.getDamageSources().sonicBoom(this), this.isPhaseTwo() ? 18.0f : 12.0f);
        t.addVelocity(n.x * 2.0, 0.4, n.z * 2.0);
        t.velocityModified = true;
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0), this);
    }

    private void shadowStep(LivingEntity t) {
        if (!t.isAlive()) return;
        ServerWorld w = (ServerWorld) this.getWorld();
        Vec3d look = t.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z).normalize();
        double[] angles = {0.0, 1.0, -1.0, 2.0, -2.0, Math.PI};
        for (double ang : angles) {
            double c = Math.cos(ang), s = Math.sin(ang);
            double bx = -flat.x, bz = -flat.z;
            double dx = bx * c - bz * s, dz = bx * s + bz * c;
            Vec3d dest = t.getPos().add(dx * 3.2, 1.2, dz * 3.2);
            Box box = this.getBoundingBox().offset(dest.x - this.getX(), dest.y - this.getY(), dest.z - this.getZ());
            if (w.isSpaceEmpty(this, box)) {
                w.spawnParticles(ParticleTypes.SCULK_SOUL, this.getX(), this.getBodyY(0.5), this.getZ(), 30, 0.5, 1.2, 0.5, 0.05);
                this.refreshPositionAndAngles(dest.x, dest.y, dest.z, this.getYaw(), this.getPitch());
                this.getNavigation().stop();
                this.fallDistance = 0.0f;
                w.spawnParticles(ParticleTypes.SCULK_SOUL, dest.x, dest.y + 1.5, dest.z, 30, 0.5, 1.2, 0.5, 0.05);
                this.playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 2.0f, 0.6f);
                this.boltCd = Math.min(this.boltCd, 15);
                return;
            }
        }
    }

    private void shriek() {
        ServerWorld w = (ServerWorld) this.getWorld();
        this.playSound(SoundEvents.ENTITY_WARDEN_ROAR, 3.0f, 0.8f);
        w.spawnParticles(ParticleTypes.SONIC_BOOM, this.getX(), this.getBodyY(0.5), this.getZ(), 1, 0, 0, 0, 0);
        for (int ring = 0; ring < 4; ring++) {
            for (int i = 0; i < 36; i++) {
                double a = i * Math.PI / 18.0;
                double r = 3.0 + ring * 3.5;
                w.spawnParticles(ParticleTypes.SCULK_SOUL, this.getX() + Math.cos(a) * r, this.getY() + 0.5,
                        this.getZ() + Math.sin(a) * r, 1, 0, 0.1, 0, 0.02);
            }
        }
        for (PlayerEntity p : this.playersWithin(14.0)) {
            p.damage(this.getDamageSources().sonicBoom(this), 10.0f);
            Vec3d away = p.getPos().subtract(this.getPos()).normalize();
            p.setVelocity(away.x * 1.6, 0.5, away.z * 1.6);
            p.velocityModified = true;
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 80, 0), this);
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 200, 0), this);
        }
    }

    @Override
    protected void onPhaseTwo() {
        EntityAttributeInstance atk = this.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (atk != null) {
            atk.removeModifier(DAMAGE_ID);
            atk.addPersistentModifier(new EntityAttributeModifier(DAMAGE_ID, "Golge Ofkesi", 6.0, EntityAttributeModifier.Operation.ADDITION));
        }
        this.playSound(SoundEvents.ENTITY_WARDEN_ROAR, 3.0f, 0.6f);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isIn(DamageTypeTags.IS_FALL)) {
            return false;
        }
        if (source.isIn(DamageTypeTags.IS_PROJECTILE)) {
            amount *= 0.5f;
        }
        if (this.getWorld().getLightLevel(this.getBlockPos()) >= 12) {
            amount *= 1.3f;
        }
        return super.damage(source, amount);
    }

    @Override
    public boolean canHaveStatusEffect(StatusEffectInstance effect) {
        if (effect.getEffectType() == StatusEffects.DARKNESS || effect.getEffectType() == StatusEffects.BLINDNESS
                || effect.getEffectType() == StatusEffects.WITHER) {
            return false;
        }
        return super.canHaveStatusEffect(effect);
    }

    @Override
    protected ParticleEffect castParticle() {
        return ParticleTypes.SCULK_SOUL;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_WARDEN_DEATH;
    }
}
