package com.korkunc.entity;

import java.util.List;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Üç bossun ortak tabanı: boss çubuğu, 2. faz (can %50), "büyü hazırlığı" (windup) sistemi.
 */
public abstract class BaseBossEntity extends HostileEntity {
    private static final TrackedData<Boolean> CASTING =
            DataTracker.registerData(BaseBossEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    protected final ServerBossBar bossBar;
    private final BossBar.Color phaseTwoColor;
    private int windup;
    private Runnable pendingCast;
    private boolean phaseTwo;

    protected BaseBossEntity(EntityType<? extends BaseBossEntity> type, World world,
                             BossBar.Color color, BossBar.Color phaseTwoColor) {
        super(type, world);
        this.bossBar = new ServerBossBar(this.getDisplayName(), color, BossBar.Style.NOTCHED_10);
        this.phaseTwoColor = phaseTwoColor;
        this.experiencePoints = 500;
        this.setPersistent();
    }

    // ------------------------------------------------------------ veri / AI
    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(CASTING, false);
    }

    public boolean isCasting() {
        return this.dataTracker.get(CASTING);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.add(5, createWanderGoal());
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 32.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    protected Goal createWanderGoal() {
        return new WanderAroundFarGoal(this, 0.6);
    }

    // ------------------------------------------------------------ boss çubuğu
    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Text name) {
        super.setCustomName(name);
        this.bossBar.setName(this.getDisplayName());
    }

    // ------------------------------------------------------------ ana döngü
    @Override
    protected void mobTick() {
        super.mobTick();
        this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());
        if (!this.phaseTwo && this.getHealth() <= this.getMaxHealth() * 0.5f) {
            this.phaseTwo = true;
            this.bossBar.setColor(this.phaseTwoColor);
            this.bossBar.setDarkenSky(true);
            this.playSound(SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 3.0f, 0.7f);
            ((ServerWorld) this.getWorld()).spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                    this.getX(), this.getBodyY(0.5), this.getZ(), 1, 0, 0, 0, 0);
            this.onPhaseTwo();
        }
        this.tickCast();
        this.tickAbilities();
    }

    protected abstract void tickAbilities();

    protected abstract void onPhaseTwo();

    protected abstract ParticleEffect castParticle();

    protected boolean isPhaseTwo() {
        return this.phaseTwo;
    }

    // ------------------------------------------------------------ yetenek hazırlığı
    protected boolean isBusy() {
        return this.windup > 0;
    }

    protected void startCast(int ticks, @Nullable SoundEvent sound, Runnable action) {
        this.windup = ticks;
        this.pendingCast = action;
        this.dataTracker.set(CASTING, true);
        if (sound != null) {
            this.playSound(sound, 2.0f, 0.9f);
        }
        this.getNavigation().stop();
    }

    private void tickCast() {
        if (this.windup <= 0) {
            return;
        }
        this.windup--;
        this.setVelocity(this.getVelocity().multiply(0.0, 1.0, 0.0));
        ((ServerWorld) this.getWorld()).spawnParticles(this.castParticle(),
                this.getX(), this.getBodyY(0.6), this.getZ(), 4,
                this.getWidth() * 0.5, this.getHeight() * 0.3, this.getWidth() * 0.5, 0.02);
        if (this.windup == 0) {
            this.dataTracker.set(CASTING, false);
            Runnable r = this.pendingCast;
            this.pendingCast = null;
            if (r != null) {
                r.run();
            }
        }
    }

    // ------------------------------------------------------------ yardımcılar
    /** Boss'un yeteneklerinden zarar görebilecek varlık mı? (yaratıklar ve diğer bosslar hariç) */
    protected boolean isValidVictim(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof HostileEntity) {
            return false;
        }
        return !(e instanceof PlayerEntity p && (p.isCreative() || p.isSpectator()));
    }

    protected List<PlayerEntity> playersWithin(double r) {
        return this.getWorld().getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(r),
                p -> p.isAlive() && EntityPredicates.EXCEPT_CREATIVE_OR_SPECTATOR.test(p)
                        && p.squaredDistanceTo(this) <= r * r);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        // Tek vuruşta ölmesin (/kill ve void hariç)
        if (!source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount = Math.min(amount, 60.0f);
        }
        return super.damage(source, amount);
    }

    // ------------------------------------------------------------ kayıt
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("PhaseTwo", this.phaseTwo);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.phaseTwo = nbt.getBoolean("PhaseTwo");
        if (this.hasCustomName()) {
            this.bossBar.setName(this.getDisplayName());
        }
        if (this.phaseTwo) {
            this.bossBar.setColor(this.phaseTwoColor);
            this.bossBar.setDarkenSky(true);
        }
    }
}
