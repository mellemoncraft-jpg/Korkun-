package com.korkunc;

import com.korkunc.item.BossSwordItem;
import com.korkunc.item.LoreItem;
import net.fabricmc.fabric.api.item.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class ModItems {
    // ---- Boss malzemeleri
    public static final Item FOREST_HEART = item("forest_heart", new LoreItem(epic().maxCount(16)));
    public static final Item CRIMSON_CORE = item("crimson_core", new LoreItem(epic().maxCount(16)));
    public static final Item SHADOW_ESSENCE = item("shadow_essence", new LoreItem(epic().maxCount(16)));

    // ---- Boss kılıçları
    public static final Item ROOT_BLADE = item("root_blade", new BossSwordItem((target, attacker) -> {
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1), attacker);
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1), attacker);
        attacker.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, 0));
    }, epic()));

    public static final Item CRIMSON_FANG = item("crimson_fang", new BossSwordItem((target, attacker) -> {
        attacker.heal(2.0f);
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60, 0), attacker);
    }, epic()));

    public static final Item SHADOW_BLADE = item("shadow_blade", new BossSwordItem((target, attacker) -> {
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0), attacker);
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 100, 0), attacker);
        attacker.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 0));
    }, epic()));

    // ---- Yumurtalar
    public static final Item FOREST_EGG = item("forest_forgotten_spawn_egg",
            new SpawnEggItem(ModEntities.FOREST_FORGOTTEN, 0x3A2A16, 0x7CD03A, new Item.Settings()));
    public static final Item PARASITE_EGG = item("crimson_parasite_spawn_egg",
            new SpawnEggItem(ModEntities.CRIMSON_PARASITE, 0x7A0F12, 0xDAD2BC, new Item.Settings()));
    public static final Item SHADOW_EGG = item("sculk_shadow_spawn_egg",
            new SpawnEggItem(ModEntities.SCULK_SHADOW, 0x0A101C, 0x38E0F0, new Item.Settings()));

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP,
            new Identifier(KorkuncMod.MOD_ID, "main"),
            FabricItemGroup.builder()
                    .displayName(Text.translatable("itemGroup.korkunc.main"))
                    .icon(() -> new ItemStack(FOREST_HEART))
                    .entries((ctx, entries) -> {
                        entries.add(FOREST_EGG);
                        entries.add(PARASITE_EGG);
                        entries.add(SHADOW_EGG);
                        entries.add(FOREST_HEART);
                        entries.add(CRIMSON_CORE);
                        entries.add(SHADOW_ESSENCE);
                        entries.add(ROOT_BLADE);
                        entries.add(CRIMSON_FANG);
                        entries.add(SHADOW_BLADE);
                    }).build());

    private static Item.Settings epic() {
        return new Item.Settings().rarity(Rarity.EPIC).fireproof();
    }

    private static Item item(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(KorkuncMod.MOD_ID, name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(FOREST_EGG);
            entries.add(PARASITE_EGG);
            entries.add(SHADOW_EGG);
        });
    }
}
