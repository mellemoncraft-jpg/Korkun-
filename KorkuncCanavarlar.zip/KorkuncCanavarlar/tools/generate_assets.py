#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Korkunç Canavarlar - model / doku / asset üretici.
Java model sınıflarını VE PNG dokularını AYNI veriden üretir (UV kayması olmaz).
Kullanım:  python3 tools/generate_assets.py      (Pillow gerekir)
Bir bossun şeklini/rengini değiştirmek için aşağıdaki PART listelerini düzenle.
"""
import json, math, os
from PIL import Image

MOD = "korkunc"
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "src/main/resources")
TEX_ENT = os.path.join(RES, "assets", MOD, "textures/entity")
TEX_ITEM = os.path.join(RES, "assets", MOD, "textures/item")
MDL_ITEM = os.path.join(RES, "assets", MOD, "models/item")
LANG = os.path.join(RES, "assets", MOD, "lang")
LOOT = os.path.join(RES, "data", MOD, "loot_tables/entities")
RECIPES = os.path.join(RES, "data", MOD, "recipes")
JAVA_MODEL = os.path.join(ROOT, "src/main/java/com/korkunc/client/model")
PREVIEW = os.path.join(ROOT, "preview")
for d in (TEX_ENT, TEX_ITEM, MDL_ITEM, LANG, LOOT, RECIPES, JAVA_MODEL, PREVIEW):
    os.makedirs(d, exist_ok=True)

# ------------------------------------------------------------------ gürültü
def ihash(x, y, seed):
    n = (x * 374761393 + y * 668265263 + seed * 1274126177) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0

def vnoise(x, y, seed):
    xi, yi = math.floor(x), math.floor(y)
    xf, yf = x - xi, y - yi
    u, v = xf * xf * (3 - 2 * xf), yf * yf * (3 - 2 * yf)
    a, b = ihash(xi, yi, seed), ihash(xi + 1, yi, seed)
    c, d = ihash(xi, yi + 1, seed), ihash(xi + 1, yi + 1, seed)
    return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v

def clamp(v): return max(0, min(255, v))
def mix(a, b, t): return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))
def shade(c, f): return tuple(clamp(c[i] * f) for i in range(3))
def ramp(cols, t):
    t = max(0.0, min(0.9999, t)) * (len(cols) - 1)
    i = int(t)
    return mix(cols[i], cols[i + 1], t - i)

# ------------------------------------------------------------------ malzemeler  (renk, parlak_mı)
def mk(cols, sx=1.0, sy=1.0, fine=0.35):
    def f(x, y, s):
        a = vnoise(x * sx, y * sy, s)
        b = vnoise(x * 2.3, y * 2.3, s + 7)
        return ramp(cols, a * (1 - fine) + b * fine), False
    return f

def glow(cols):
    def f(x, y, s):
        return ramp(cols, vnoise(x * 0.9, y * 0.9, s) * 0.6 + 0.35), True
    return f

def m_bark(x, y, s):
    streak = vnoise(x * 0.8, y * 0.10, s)
    fine = vnoise(x * 2.3, y * 1.1, s + 7)
    c = ramp([(26, 16, 9), (52, 32, 18), (84, 55, 30), (116, 80, 46)], streak * 0.65 + fine * 0.35)
    if vnoise(x * 0.55, y * 0.22, s + 3) > 0.80: c = shade(c, 0.55)
    if vnoise(x * 0.3, y * 0.3, s + 11) > 0.74 and fine > 0.45: c = mix(c, (54, 92, 38), 0.7)
    return c, False

def m_mush_cap(x, y, s):
    c = ramp([(110, 30, 26), (150, 48, 36), (186, 76, 52)], vnoise(x * 0.8, y * 0.8, s))
    if vnoise(x * 1.3, y * 1.3, s + 5) > 0.78: c = (232, 222, 200)
    return c, False

def m_metal(x, y, s):
    c = ramp([(40, 42, 48), (70, 74, 82), (104, 108, 118), (138, 142, 150)],
             vnoise(x * 1.2, y * 0.25, s) * 0.6 + vnoise(x * 2.4, y * 2.4, s + 3) * 0.4)
    if vnoise(x * 0.5, y * 0.5, s + 9) > 0.74: c = mix(c, (112, 54, 28), 0.75)
    if int(x) % 7 == 0 and int(y) % 5 == 0: c = shade(c, 0.5)  # perçin
    return c, False

def m_bone(x, y, s):
    c = ramp([(150, 140, 120), (190, 180, 158), (222, 214, 194), (236, 230, 212)],
             vnoise(x * 0.7, y * 0.4, s) * 0.6 + vnoise(x * 2.1, y * 2.1, s + 4) * 0.4)
    if vnoise(x * 0.6, y * 0.6, s + 13) > 0.78: c = mix(c, (112, 22, 22), 0.8)
    return c, False

def m_flesh(x, y, s):
    c = ramp([(60, 6, 10), (100, 14, 16), (140, 26, 24), (170, 48, 40)], vnoise(x * 0.8, y * 0.8, s))
    if abs(vnoise(x * 0.5, y * 0.5, s + 2) - 0.5) < 0.04: c = (36, 0, 6)
    return c, False

def m_sculk(x, y, s):
    c = ramp([(6, 40, 50), (10, 70, 84), (18, 110, 124), (40, 170, 180)], vnoise(x * 0.9, y * 0.9, s) * 0.8)
    if vnoise(x * 1.7, y * 1.7, s + 21) > 0.86: return (90, 235, 245), True
    return c, False

MATS = {
    "bark": m_bark,
    "darkbark": mk([(18, 12, 8), (34, 22, 14), (52, 36, 22), (70, 48, 30)], 0.8, 0.12),
    "moss": mk([(26, 48, 20), (44, 82, 30), (70, 116, 42), (98, 140, 56)], 0.9, 0.9, 0.5),
    "vine": mk([(30, 70, 26), (60, 120, 40), (92, 160, 58)], 0.9, 0.3),
    "mush_cap": m_mush_cap,
    "mush_stem": mk([(170, 160, 140), (210, 200, 180)]),
    "glow_orange": glow([(200, 90, 10), (250, 160, 30), (255, 220, 100)]),
    "metal": m_metal,
    "rust": mk([(60, 32, 20), (100, 50, 26), (140, 76, 36)], 1.0, 0.5),
    "bone": m_bone,
    "flesh": m_flesh,
    "blood_tank": mk([(90, 6, 8), (140, 12, 14), (190, 24, 24)], 0.4, 1.5),
    "claw": mk([(120, 120, 130), (180, 182, 190), (225, 228, 235)], 0.5, 0.5),
    "glow_red": glow([(190, 20, 20), (255, 60, 40), (255, 150, 120)]),
    "shadow": mk([(6, 8, 16), (10, 14, 26), (16, 22, 40), (24, 32, 56)], 0.8, 0.8, 0.5),
    "shadow2": mk([(4, 6, 12), (8, 10, 20), (12, 18, 34)], 0.8, 0.8, 0.5),
    "sculk": m_sculk,
    "glow_cyan": glow([(60, 200, 220), (110, 240, 250), (220, 255, 255)]),
}

# ------------------------------------------------------------------ yüz süslemeleri (göz, ağız vb.)
def D_forest_face(face, lx, ly, fw, fh, c, e):
    if face != "front": return c, e
    if 3 <= ly <= 6 and (1 <= lx <= 4 or 5 <= lx <= 8): c, e = (10, 6, 4), False
    if 4 <= ly <= 5 and (2 <= lx <= 3 or 6 <= lx <= 7):
        return ((255, 170, 40) if ly == 4 else (255, 215, 90)), True
    if 7 <= ly <= 8 and 4 <= lx <= 5: c = shade(c, 0.45)
    if 9 <= ly <= 11 and 2 <= lx <= 7:
        c, e = (8, 4, 3), False
        if ly == 9 and lx % 2 == 0: c = (168, 128, 78)
        if ly == 10 and 3 <= lx <= 6: c, e = (190, 80, 12), True
        if ly == 11 and lx % 2 == 1: c = (150, 110, 66)
    return c, e

def D_skull_face(face, lx, ly, fw, fh, c, e):
    if face != "front": return c, e
    if 3 <= ly <= 4 and (1 <= lx <= 2 or 5 <= lx <= 6):
        if ly == 4 and lx in (2, 5): return (255, 50, 40), True
        return (8, 3, 3), False
    if 5 <= ly <= 6 and 3 <= lx <= 4: return (14, 6, 6), False
    if ly == 7 and lx % 2 == 0: return shade(c, 0.45), False
    if (lx, ly) in ((0, 5), (0, 6), (7, 5)): return (120, 12, 12), False
    return c, e

def D_teeth(face, lx, ly, fw, fh, c, e):
    if face == "front" and ly == 0:
        return ((232, 226, 204) if lx % 2 == 0 else (40, 28, 24)), False
    return c, e

def D_shadow_face(face, lx, ly, fw, fh, c, e):
    if face != "front": return c, e
    if lx in (1, 2, 5, 6):
        if ly == 4: return (130, 250, 255), True
        if ly in (3, 5): return (20, 110, 130), True
    return c, e

DECOS = {"forest_face": D_forest_face, "skull_face": D_skull_face, "teeth": D_teeth, "shadow_face": D_shadow_face}
FACE_SHADE = {"top": 1.12, "bottom": 0.65, "right": 0.88, "left": 0.88, "front": 1.0, "back": 0.8}

# ------------------------------------------------------------------ model veri yapısı
class B:
    """Kutu: pivota göre (x,y,z) alt-sol-ön köşe, y YUKARI pozitif. w,h,d tam sayı."""
    def __init__(s, x, y, z, w, h, d, mat, deco=None):
        s.x, s.y, s.z, s.w, s.h, s.d, s.mat, s.deco = x, y, z, int(w), int(h), int(d), mat, deco
        s.u = s.v = 0
        s.rw, s.rh = 2 * s.d + 2 * s.w, s.d + s.h

class Part:
    """pivot = MUTLAK konum (ayak=0, y yukarı), parent'ın dönmemiş çerçevesinde. rot = (pitch,yaw,roll) model uzayı."""
    def __init__(s, name, parent, pivot, boxes, rot=(0, 0, 0)):
        s.name, s.parent, s.pivot, s.boxes, s.rot = name, parent, pivot, boxes, rot

def pack(parts):
    boxes = [b for p in parts for b in p.boxes]
    for size in (64, 128, 256, 512):
        x = y = rowh = 0
        ok = True
        for b in sorted(boxes, key=lambda b: -b.rh):
            if x + b.rw + 1 > size: x, y, rowh = 0, y + rowh + 1, 0
            b.u, b.v = x, y
            x += b.rw + 1
            rowh = max(rowh, b.rh)
            if y + b.rh > size: ok = False; break
        if ok: return size
    raise RuntimeError("doku sığmadı")

def paint(parts, size, name):
    base = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    glw = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    for bi, b in enumerate([b for p in parts for b in p.boxes]):
        faces = {
            "top": (b.u + b.d, b.v, b.w, b.d), "bottom": (b.u + b.d + b.w, b.v, b.w, b.d),
            "right": (b.u, b.v + b.d, b.d, b.h), "front": (b.u + b.d, b.v + b.d, b.w, b.h),
            "left": (b.u + b.d + b.w, b.v + b.d, b.d, b.h), "back": (b.u + 2 * b.d + b.w, b.v + b.d, b.w, b.h),
        }
        deco = DECOS.get(b.deco)
        for fname, (x0, y0, fw, fh) in faces.items():
            for ly in range(fh):
                for lx in range(fw):
                    c, e = MATS[b.mat](x0 + lx, y0 + ly, bi * 13 + 1)
                    c = shade(c, FACE_SHADE[fname])
                    if not e and (lx in (0, fw - 1) or ly in (0, fh - 1)): c = shade(c, 0.86)
                    if deco: c, e = deco(fname, lx, ly, fw, fh, c, e)
                    px = tuple(int(v) for v in c)
                    base.putpixel((x0 + lx, y0 + ly), px + (255,))
                    if e: glw.putpixel((x0 + lx, y0 + ly), px + (255,))
    base.save(os.path.join(TEX_ENT, name + ".png"))
    glw.save(os.path.join(TEX_ENT, name + "_glow.png"))
    # önizleme (3x)
    sheet = Image.new("RGBA", (size, size), (24, 24, 28, 255))
    sheet.alpha_composite(base)
    sheet.resize((size * 3, size * 3), Image.NEAREST).save(os.path.join(PREVIEW, name + "_doku.png"))

def F(v):
    s = ("%.4f" % v).rstrip("0").rstrip(".")
    if s in ("-0", ""): s = "0"
    return s + "f"

JAVA_TMPL = '''package com.korkunc.client.model;

import com.korkunc.entity.@@E@@;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** OTOMATİK ÜRETİLDİ (tools/generate_assets.py). Elle düzenleme; betiği düzenle. */
public class @@C@@ extends SinglePartEntityModel<@@E@@> {
    private final ModelPart root;
@@FIELDS@@
    public @@C@@(ModelPart root) {
        this.root = root;
@@INIT@@
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
@@BUILD@@
        return TexturedModelData.of(data, @@S@@, @@S@@);
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }

    @Override
    public void setAngles(@@E@@ e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        this.getPart().traverse().forEach(ModelPart::resetTransform);
@@ANIM@@
    }
}
'''

def build(cls, entity, tex, parts, anim):
    size = pack(parts)
    paint(parts, size, tex)
    absp = {p.name: p.pivot for p in parts}
    fields, init, bld = [], [], []
    for p in parts:
        fields.append("    private final ModelPart %s;" % p.name)
        par = "root" if p.parent is None else "this." + p.parent
        init.append('        this.%s = %s.getChild("%s");' % (p.name, par, p.name))
        if p.parent is None:
            px, py, pz = p.pivot[0], 24 - p.pivot[1], p.pivot[2]
            pv = "root"
        else:
            q = absp[p.parent]
            px, py, pz = p.pivot[0] - q[0], q[1] - p.pivot[1], p.pivot[2] - q[2]
            pv = "d_" + p.parent
        cub = "".join("\n                .uv(%d, %d).cuboid(%s, %s, %s, %s, %s, %s)" % (
            b.u, b.v, F(b.x), F(-(b.y + b.h)), F(b.z), F(b.w), F(b.h), F(b.d)) for b in p.boxes)
        if any(abs(r) > 1e-6 for r in p.rot):
            tr = "ModelTransform.of(%s, %s, %s, %s, %s, %s)" % (F(px), F(py), F(pz), F(p.rot[0]), F(p.rot[1]), F(p.rot[2]))
        else:
            tr = "ModelTransform.pivot(%s, %s, %s)" % (F(px), F(py), F(pz))
        bld.append('        ModelPartData d_%s = %s.addChild("%s", ModelPartBuilder.create()%s,\n                %s);' % (p.name, pv, p.name, cub, tr))
    src = (JAVA_TMPL.replace("@@E@@", entity).replace("@@C@@", cls).replace("@@S@@", str(size))
           .replace("@@FIELDS@@", "\n".join(fields)).replace("@@INIT@@", "\n".join(init))
           .replace("@@BUILD@@", "\n".join(bld)).replace("@@ANIM@@", anim.rstrip("\n")))
    with open(os.path.join(JAVA_MODEL, cls + ".java"), "w", encoding="utf-8") as f: f.write(src)
    print(cls, "-> doku", size, "px,", len(parts), "parça")

# =================================================================== 1) ORMAN UNUTULANI
forest = []
for side, sx in (("R", -1), ("L", 1)):
    forest.append(Part("leg" + side, None, (sx * 7, 30, 0), [B(-4.5, -26, -4.5, 9, 26, 9, "bark"),
        B(-5, -9, -5, 10, 4, 10, "moss"), B(-5, -17, -5, 10, 3, 10, "darkbark")]))
    forest.append(Part("foot" + side, "leg" + side, (sx * 7, 4, 0), [B(-5, -4, -8, 10, 4, 13, "darkbark")]))
forest.append(Part("body", None, (0, 30, 0), [
    B(-9, 0, -6, 18, 26, 12, "bark"), B(-7, 5, -8, 14, 16, 2, "darkbark"),
    B(-2, 11, -9, 4, 4, 1, "glow_orange"), B(-6, 3, -9, 1, 18, 1, "vine"), B(5, 1, -9, 1, 20, 1, "vine")]))
forest.append(Part("spikeBack1", "body", (-6, 48, 6), [B(-1.5, 0, -1.5, 3, 16, 3, "darkbark")], (-0.5, 0, -0.2)))
forest.append(Part("spikeBack2", "body", (0, 52, 6), [B(-2, 0, -2, 4, 20, 4, "darkbark")], (-0.6, 0, 0)))
forest.append(Part("spikeBack3", "body", (6, 48, 6), [B(-1.5, 0, -1.5, 3, 16, 3, "darkbark")], (-0.5, 0, 0.2)))
forest.append(Part("head", "body", (0, 56, 0), [
    B(-5, 0, -5, 10, 14, 10, "bark", "forest_face"), B(-5.5, 12, -5.5, 11, 3, 11, "moss"),
    B(2.5, 15, -1, 2, 3, 2, "mush_stem"), B(1, 18, -2.5, 5, 2, 5, "mush_cap"), B(-4, -3, -4, 8, 3, 8, "darkbark")]))
for side, sx in (("R", -1), ("L", 1)):
    forest.append(Part("antler" + side, "head", (sx * 4, 13, 0), [B(-1, 0, -1, 2, 14, 2, "darkbark")], (0, 0, sx * 0.5)))
    forest.append(Part("tine" + side, "antler" + side, (sx * 4, 21, 0), [B(-1, 0, -1, 2, 10, 2, "darkbark")], (0, 0, sx * 0.9)))
    forest.append(Part("arm" + side, "body", (sx * 13, 52, 0), [
        B(-4.5, -17, -4.5, 9, 17, 9, "bark"), B(-6, -4, -6, 12, 6, 12, "darkbark"),
        B(-1, 2, -1, 2, 3, 2, "mush_stem"), B(-3, 5, -3, 6, 2, 6, "mush_cap")], (0, 0, -sx * 0.12)))
    forest.append(Part("forearm" + side, "arm" + side, (sx * 13, 35, 0), [
        B(-5, -15, -5, 10, 15, 10, "bark"), B(-5.5, -9, -5.5, 11, 2, 11, "moss")]))
    forest.append(Part("hand" + side, "forearm" + side, (sx * 13, 20, 0), [
        B(-5.5, -9, -5.5, 11, 9, 11, "darkbark"), B(-5, -14, -6, 2, 5, 2, "bark"), B(-1, -15, -6, 2, 6, 2, "bark"),
        B(3, -14, -6, 2, 5, 2, "bark"), B(-1, -13, 4, 2, 4, 2, "bark")]))
    forest.append(Part("thorn" + side, "body", (sx * 16, 54, 0), [B(-1.5, 0, -1.5, 3, 12, 3, "darkbark")], (0, 0, sx * 0.9)))

FOREST_ANIM = '''        float swing = limbAngle * 0.5f;
        float amp = Math.min(limbDistance, 1.0f);
        this.legR.pitch += MathHelper.cos(swing) * 1.0f * amp;
        this.legL.pitch += MathHelper.cos(swing + MathHelper.PI) * 1.0f * amp;
        this.armR.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.6f * amp;
        this.armL.pitch += MathHelper.cos(swing) * 0.6f * amp;
        this.body.roll += MathHelper.cos(swing) * 0.05f * amp;
        float breathe = MathHelper.sin(anim * 0.07f);
        this.armR.roll += 0.03f * breathe;
        this.armL.roll -= 0.03f * breathe;
        this.forearmR.pitch += -0.15f + 0.05f * breathe;
        this.forearmL.pitch += -0.15f + 0.05f * breathe;
        this.head.yaw += headYaw * 0.017453292f * 0.7f;
        this.head.pitch += headPitch * 0.017453292f * 0.7f;
        if (e.isCasting()) {
            this.armR.pitch += -2.5f + MathHelper.sin(anim * 0.4f) * 0.1f;
            this.armL.pitch += -2.5f - MathHelper.sin(anim * 0.4f) * 0.1f;
            this.head.pitch += -0.35f;
        } else if (e.isAttacking()) {
            float s = MathHelper.sin(anim * 0.45f);
            this.armR.pitch += -1.4f + s * 0.7f;
            this.armL.pitch += -1.4f - s * 0.7f;
        }'''

# =================================================================== 2) KIZIL PARAZİT
par = [Part("pelvis", None, (0, 22, 0), [B(-4, 0, -3, 8, 4, 6, "metal"), B(-3, -3, -2.5, 6, 3, 5, "flesh")])]
par.append(Part("torso", "pelvis", (0, 26, 0), [
    B(-5, 0, -3, 10, 16, 6, "flesh"), B(-5.5, 3, -3.5, 11, 2, 7, "bone"), B(-5.5, 7, -3.5, 11, 2, 7, "bone"),
    B(-5.5, 11, -3.5, 11, 2, 7, "bone"), B(-1, 0, 3, 2, 16, 2, "bone"), B(-4, 4, 4, 3, 10, 3, "blood_tank"),
    B(1, 4, 4, 3, 10, 3, "blood_tank"), B(-2, 6, -4, 4, 4, 1, "glow_red")], (0.25, 0, 0)))
par.append(Part("head", "torso", (0, 42, 0), [
    B(-4, 0, -4, 8, 8, 8, "bone", "skull_face"), B(-4.5, 5, -4.5, 9, 3, 9, "metal"),
    B(-0.5, 8, -0.5, 1, 3, 1, "metal"), B(-1.5, -3, -1.5, 3, 3, 3, "bone")], (-0.25, 0, 0)))
par.append(Part("jaw", "head", (0, 42.5, -0.5), [B(-3, -3, -3.5, 6, 3, 6, "bone", "teeth")]))
par.append(Part("armR", "torso", (-6.5, 40, 0), [B(-1.5, -12, -1.5, 3, 12, 3, "bone"), B(-3, -2, -3, 6, 4, 6, "metal")], (0, 0, 0.15)))
par.append(Part("forearmR", "armR", (-6.5, 28, 0), [B(-2, -12, -2, 4, 12, 4, "flesh"), B(-2.5, -7, -2.5, 5, 4, 5, "metal"),
    B(-2, -18, -2, 1, 6, 1, "claw"), B(-0.5, -19, -2, 1, 7, 1, "claw"), B(1, -18, -2, 1, 6, 1, "claw"), B(-0.5, -17, 1, 1, 5, 1, "claw")]))
par.append(Part("armL", "torso", (6.5, 40, 0), [B(-1.5, -12, -1.5, 3, 12, 3, "bone"), B(-3, -2, -3, 6, 4, 6, "metal")], (0, 0, -0.15)))
par.append(Part("forearmL", "armL", (6.5, 28, 0), [B(-2.5, -14, -2.5, 5, 14, 5, "metal"), B(-3, -18, -3, 6, 4, 6, "rust"),
    B(-3, -9, -3, 6, 2, 6, "blood_tank")]))
for side, sx in (("R", -1), ("L", 1)):
    par.append(Part("pipe" + side, "torso", (sx * 6, 40, 3), [B(-1.5, 0, -1.5, 3, 12, 3, "metal")], (-0.2, 0, sx * 0.5)))
    par.append(Part("leg" + side, "pelvis", (sx * 3, 22, 0), [B(-1.5, -11, -1.5, 3, 11, 3, "metal"), B(-2, -4, -2, 4, 4, 4, "flesh")], (-0.6, 0, 0)))
    par.append(Part("shin" + side, "leg" + side, (sx * 3, 11, 0), [B(-1, -14, -1, 2, 14, 2, "bone"), B(-1.5, -8, -1.5, 3, 3, 3, "metal")], (1.2, 0, 0)))
    par.append(Part("foot" + side, "shin" + side, (sx * 3, -3, 0), [B(-1.5, -1, -6, 3, 2, 7, "claw")], (-0.6, 0, 0)))
    for idx, (zz, yy) in enumerate(((-2.5, 33), (2.5, 31.5)), 1):
        n = "sp%s%d" % (side, idx)
        par.append(Part(n, "torso", (sx * 5, yy, zz), [B(-1, -10, -1, 2, 10, 2, "metal")], (0, 0, -sx * 1.1)))
        par.append(Part(n + "b", n, (sx * 5, yy - 10, zz), [B(-1, -27, -1, 2, 27, 2, "bone"), B(-1.5, -6, -1.5, 3, 3, 3, "metal")], (0, 0, sx * 1.2)))
    par.append(Part("tent" + side, "torso", (sx * 3, 36, -3), [B(-1, -12, -1, 2, 12, 2, "flesh")], (-0.4, 0, -sx * 0.2)))
    par.append(Part("tent%s2" % side, "tent" + side, (sx * 3, 24, -3), [B(-1, -12, -1, 2, 12, 2, "blood_tank")]))

PAR_ANIM = '''        float swing = limbAngle * 0.8f;
        float amp = Math.min(limbDistance, 1.0f);
        this.legR.pitch += MathHelper.cos(swing) * 0.9f * amp;
        this.legL.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.9f * amp;
        this.armR.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.6f * amp;
        this.armL.pitch += MathHelper.cos(swing) * 0.4f * amp;
        this.spR1.pitch += MathHelper.cos(swing) * 0.5f * amp;
        this.spL2.pitch += MathHelper.cos(swing) * 0.5f * amp;
        this.spL1.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.5f * amp;
        this.spR2.pitch += MathHelper.cos(swing + MathHelper.PI) * 0.5f * amp;
        float idle = MathHelper.sin(anim * 0.1f);
        this.torso.pitch += 0.03f * idle + amp * 0.1f;
        this.tentR.pitch += 0.25f * idle;
        this.tentR2.pitch += 0.4f * MathHelper.sin(anim * 0.1f - 0.9f);
        this.tentL.pitch -= 0.25f * idle;
        this.tentL2.pitch += 0.4f * MathHelper.sin(anim * 0.1f - 0.9f + MathHelper.PI);
        this.jaw.pitch += 0.12f + 0.06f * MathHelper.sin(anim * 0.25f);
        this.head.yaw += headYaw * 0.017453292f * 0.8f;
        this.head.pitch += headPitch * 0.017453292f * 0.8f;
        if (e.isCasting()) {
            this.armR.pitch += -2.0f;
            this.armL.pitch += -1.55f;
            this.jaw.pitch += 0.7f;
            this.head.pitch += -0.2f;
        } else if (e.isAttacking()) {
            this.armR.pitch += -1.3f + MathHelper.sin(anim * 0.5f) * 0.8f;
            this.armL.pitch += -0.6f;
            this.jaw.pitch += 0.4f;
        }'''

# =================================================================== 3) SKULK GÖLGESİ
sh = [Part("torso", None, (0, 32, 0), [
    B(-5, 0, -3, 10, 20, 6, "shadow"), B(-5.5, 3, -3.5, 11, 1, 7, "sculk"), B(-5.5, 16, -3.5, 11, 1, 7, "sculk"),
    B(-5.5, 18, -3.5, 11, 1, 7, "sculk"), B(-2.5, 7, -3.8, 5, 6, 1, "glow_cyan"), B(-8, 15, -3.5, 16, 5, 7, "shadow2")])]
sh.append(Part("head", "torso", (0, 52, 0), [
    B(-4, 0, -4, 8, 10, 8, "shadow", "shadow_face"), B(-4.5, 8, -4.5, 9, 3, 9, "shadow2"),
    B(-3, -3, -3, 6, 3, 6, "shadow2"), B(-0.5, 11, -3, 1, 4, 6, "sculk")]))
sh.append(Part("tail1", "torso", (0, 32, 0), [B(-4, -12, -2.5, 8, 12, 5, "shadow")]))
sh.append(Part("tail2", "tail1", (0, 20, 0), [B(-3, -12, -2, 6, 12, 4, "shadow2")]))
sh.append(Part("tail3", "tail2", (0, 8, 0), [B(-2, -5, -1.5, 4, 5, 3, "sculk")]))
for side, sx in (("R", -1), ("L", 1)):
    sh.append(Part("horn" + side, "head", (sx * 3, 10, 0), [B(-1, 0, -1, 2, 9, 2, "sculk")], (0, 0, sx * 0.5)))
    sh.append(Part("arm%s1" % side, "torso", (sx * 7, 48, 0), [B(-1.5, -13, -1.5, 3, 13, 3, "shadow"), B(-2, -3, -2, 4, 4, 4, "shadow2")], (0, 0, -sx * 0.3)))
    sh.append(Part("arm%s1b" % side, "arm%s1" % side, (sx * 7, 35, 0), [B(-1, -16, -1, 2, 16, 2, "shadow2"), B(-1.5, -20, -1.5, 3, 4, 3, "shadow"),
        B(-1.5, -24, -1.5, 1, 4, 1, "shadow"), B(0.5, -24, -1.5, 1, 4, 1, "shadow"), B(-0.5, -23, 0.5, 1, 3, 1, "shadow")]))
    sh.append(Part("arm%s2" % side, "torso", (sx * 5, 50, 0), [B(-1.5, -12, -1.5, 3, 12, 3, "shadow")], (0, 0, -sx * 2.0)))
    sh.append(Part("arm%s2b" % side, "arm%s2" % side, (sx * 5, 38, 0), [B(-1, -15, -1, 2, 15, 2, "shadow2"), B(-1.5, -19, -1.5, 3, 4, 3, "shadow"),
        B(-1.5, -23, -1.5, 1, 4, 1, "shadow"), B(0.5, -23, -1.5, 1, 4, 1, "shadow")], (0, 0, -sx * 0.5)))
    sh.append(Part("wisp" + side, "torso", (sx * 4, 34, 0), [B(-1, -14, -1, 2, 14, 2, "sculk")], (0, 0, -sx * 0.5)))
    sh.append(Part("wisp%sb" % side, "wisp" + side, (sx * 4, 20, 0), [B(-1, -10, -1, 2, 10, 2, "shadow2")], (0, 0, sx * 0.6)))

SH_ANIM = '''        float bob = MathHelper.sin(anim * 0.08f);
        float amp = Math.min(limbDistance, 1.0f);
        this.torso.pivotY += bob * 1.2f;
        this.torso.pitch += amp * 0.3f;
        this.tail1.pitch += 0.12f + amp * 0.5f + MathHelper.sin(anim * 0.1f) * 0.08f;
        this.tail1.yaw += MathHelper.sin(anim * 0.07f) * 0.12f;
        this.tail2.pitch += amp * 0.2f + MathHelper.sin(anim * 0.1f - 0.7f) * 0.15f;
        this.tail2.yaw += MathHelper.sin(anim * 0.07f - 0.6f) * 0.15f;
        this.tail3.pitch += MathHelper.sin(anim * 0.1f - 1.4f) * 0.2f;
        this.tail3.yaw += MathHelper.sin(anim * 0.07f - 1.2f) * 0.2f;
        float sway = MathHelper.sin(anim * 0.09f) * 0.08f;
        this.armR1.roll += sway;
        this.armL1.roll -= sway;
        this.armR2.roll += sway * 1.5f;
        this.armL2.roll -= sway * 1.5f;
        this.armR1b.pitch += -0.25f + MathHelper.sin(anim * 0.09f + 0.8f) * 0.15f;
        this.armL1b.pitch += -0.25f + MathHelper.sin(anim * 0.09f + 2.4f) * 0.15f;
        this.armR2b.pitch += MathHelper.sin(anim * 0.07f) * 0.12f;
        this.armL2b.pitch += MathHelper.sin(anim * 0.07f + 1.5f) * 0.12f;
        float w = MathHelper.sin(anim * 0.1f) * 0.15f;
        this.wispR.roll += w;
        this.wispL.roll -= w;
        this.wispRb.roll += MathHelper.sin(anim * 0.1f - 0.8f) * 0.2f;
        this.wispLb.roll -= MathHelper.sin(anim * 0.1f - 0.8f) * 0.2f;
        this.head.yaw += headYaw * 0.017453292f * 0.8f;
        this.head.pitch += headPitch * 0.017453292f * 0.8f;
        if (e.isCasting()) {
            this.armR1.pitch += -1.5f;
            this.armL1.pitch += -1.5f;
            this.armR2.roll += 0.4f;
            this.armL2.roll -= 0.4f;
            this.torso.pitch += -0.1f;
            this.head.pitch += -0.25f;
        } else if (e.isAttacking()) {
            float s = MathHelper.sin(anim * 0.5f);
            this.armR1.pitch += -1.2f + s * 0.7f;
            this.armL1.pitch += -1.2f - s * 0.7f;
        }'''

build("ForestForgottenModel", "ForestForgottenEntity", "forest_forgotten", forest, FOREST_ANIM)
build("CrimsonParasiteModel", "CrimsonParasiteEntity", "crimson_parasite", par, PAR_ANIM)
build("SculkShadowModel", "SculkShadowEntity", "sculk_shadow", sh, SH_ANIM)

# =================================================================== EŞYA DOKULARI (16x16)
def item_img(fn):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y in range(16):
        for x in range(16):
            r = fn(x, y)
            if r: im.putpixel((x, y), tuple(int(clamp(v)) for v in r[:3]) + (255,))
    return im

def orb(pal, core, style):
    def fn(x, y):
        dx, dy = x - 7.5, y - 7.5
        r = math.hypot(dx, dy)
        ang = math.atan2(dy, dx)
        if style == "gear" and 6.2 < r <= 7.6 and int((ang + math.pi) / (math.pi / 4)) % 2 == 0:
            return (150, 154, 164)
        if r > 6.4: return None
        light = 0.5 - (dx * 0.5 + dy * 0.7) / 14 + vnoise(x * 0.9, y * 0.9, 3) * 0.3
        c = ramp(pal, light)
        if style == "shadow" and math.sin(ang * 2 + r * 0.9) > 0.6: c = (40, 190, 210)
        if style == "gear" and 5.2 < r <= 6.4: c = (90, 94, 104)
        if r <= 3.0: c = ramp(core, 0.5 + (3 - r) / 6 + vnoise(x, y, 8) * 0.2)
        return c
    return fn

def sword(blade, edge, guard, grip, gem):
    pts = {}
    for i in range(9): pts[(14 - i, 1 + i)] = blade; pts[(15 - i, 1 + i)] = edge
    pts[(14, 1)] = edge
    for d in (-2, -1, 0, 1, 2): pts[(5 + d, 10 + d)] = guard
    pts[(5, 10)] = gem
    for (x, y) in ((4, 11), (3, 12), (2, 13)): pts[(x, y)] = grip
    pts[(1, 14)] = guard
    return lambda x, y: pts.get((x, y))

items = {
    "forest_heart": orb([(40, 24, 12), (82, 56, 30), (120, 86, 48), (70, 120, 40)], [(200, 90, 10), (255, 190, 50), (255, 240, 150)], "knot"),
    "crimson_core": orb([(60, 6, 10), (120, 16, 18), (180, 36, 32)], [(180, 20, 20), (255, 70, 50), (255, 190, 160)], "gear"),
    "shadow_essence": orb([(4, 6, 12), (10, 16, 30), (22, 34, 60)], [(40, 190, 210), (120, 240, 250), (230, 255, 255)], "shadow"),
    "root_blade": sword((96, 66, 36), (60, 120, 40), (40, 28, 16), (30, 70, 26), (255, 170, 40)),
    "crimson_fang": sword((226, 218, 196), (150, 20, 20), (90, 94, 104), (60, 6, 10), (255, 60, 40)),
    "shadow_blade": sword((16, 22, 40), (40, 190, 210), (6, 8, 16), (10, 14, 26), (130, 250, 255)),
}
for n, fn in items.items(): item_img(fn).save(os.path.join(TEX_ITEM, n + ".png"))

# =================================================================== JSON
def wj(path, obj):
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=2)

for n in ("forest_heart", "crimson_core", "shadow_essence"):
    wj(os.path.join(MDL_ITEM, n + ".json"), {"parent": "minecraft:item/generated", "textures": {"layer0": "%s:item/%s" % (MOD, n)}})
for n in ("root_blade", "crimson_fang", "shadow_blade"):
    wj(os.path.join(MDL_ITEM, n + ".json"), {"parent": "minecraft:item/handheld", "textures": {"layer0": "%s:item/%s" % (MOD, n)}})
for n in ("forest_forgotten", "crimson_parasite", "sculk_shadow"):
    wj(os.path.join(MDL_ITEM, n + "_spawn_egg.json"), {"parent": "minecraft:item/template_spawn_egg"})

TR = {
    "itemGroup.korkunc.main": "Korkunç Canavarlar",
    "entity.korkunc.forest_forgotten": "Orman Unutulanı",
    "entity.korkunc.crimson_parasite": "Kızıl Parazit",
    "entity.korkunc.sculk_shadow": "Skulk Gölgesi",
    "item.korkunc.forest_forgotten_spawn_egg": "Orman Unutulanı Yumurtası",
    "item.korkunc.crimson_parasite_spawn_egg": "Kızıl Parazit Yumurtası",
    "item.korkunc.sculk_shadow_spawn_egg": "Skulk Gölgesi Yumurtası",
    "item.korkunc.forest_heart": "Orman Kalbi",
    "item.korkunc.forest_heart.tooltip": "Orman Unutulanı'nın hâlâ atan kalbi.",
    "item.korkunc.crimson_core": "Kızıl Çekirdek",
    "item.korkunc.crimson_core.tooltip": "Kızıl Parazit'in zonklayan makine-et çekirdeği.",
    "item.korkunc.shadow_essence": "Skulk Özü",
    "item.korkunc.shadow_essence.tooltip": "Skulk Gölgesi'nden geriye kalan soğuk öz.",
    "item.korkunc.root_blade": "Unutulmuş Kök Kılıcı",
    "item.korkunc.root_blade.tooltip": "Zehirler ve yavaşlatır; vurdukça seni yeniler.",
    "item.korkunc.crimson_fang": "Kızıl Diş",
    "item.korkunc.crimson_fang.tooltip": "Yaşam çalar ve düşmanı soldurur.",
    "item.korkunc.shadow_blade": "Gölge Bıçağı",
    "item.korkunc.shadow_blade.tooltip": "Düşmanı karanlığa gömer, seni hızlandırır.",
}
EN = {
    "itemGroup.korkunc.main": "Dread Bosses",
    "entity.korkunc.forest_forgotten": "Forest Forgotten",
    "entity.korkunc.crimson_parasite": "Crimson Parasite",
    "entity.korkunc.sculk_shadow": "Sculk Shadow",
    "item.korkunc.forest_forgotten_spawn_egg": "Forest Forgotten Spawn Egg",
    "item.korkunc.crimson_parasite_spawn_egg": "Crimson Parasite Spawn Egg",
    "item.korkunc.sculk_shadow_spawn_egg": "Sculk Shadow Spawn Egg",
    "item.korkunc.forest_heart": "Heart of the Forest",
    "item.korkunc.forest_heart.tooltip": "The still-beating heart of the Forest Forgotten.",
    "item.korkunc.crimson_core": "Crimson Core",
    "item.korkunc.crimson_core.tooltip": "The pulsing flesh-machine core of the Crimson Parasite.",
    "item.korkunc.shadow_essence": "Sculk Essence",
    "item.korkunc.shadow_essence.tooltip": "Cold essence left by the Sculk Shadow.",
    "item.korkunc.root_blade": "Forgotten Root Blade",
    "item.korkunc.root_blade.tooltip": "Poisons and slows; heals you as you strike.",
    "item.korkunc.crimson_fang": "Crimson Fang",
    "item.korkunc.crimson_fang.tooltip": "Steals life and withers the target.",
    "item.korkunc.shadow_blade": "Shadow Blade",
    "item.korkunc.shadow_blade.tooltip": "Plunges foes into darkness and hastens you.",
}
wj(os.path.join(LANG, "tr_tr.json"), TR)
wj(os.path.join(LANG, "en_us.json"), EN)

def loot(heart, extra):
    pools = [
        {"rolls": 1, "entries": [{"type": "minecraft:item", "name": "%s:%s" % (MOD, heart)}]},
        {"rolls": 1, "entries": [{"type": "minecraft:item", "name": "minecraft:diamond",
            "functions": [{"function": "minecraft:set_count", "count": {"min": 3, "max": 8}},
                          {"function": "minecraft:looting_enchant", "count": {"min": 0, "max": 2}}]}]},
        {"rolls": 1, "entries": [{"type": "minecraft:item", "name": "minecraft:netherite_scrap",
            "functions": [{"function": "minecraft:set_count", "count": {"min": 1, "max": 3}}]}]},
        {"rolls": 1, "conditions": [{"condition": "minecraft:random_chance", "chance": 0.3}],
         "entries": [{"type": "minecraft:item", "name": extra}]},
    ]
    return {"type": "minecraft:entity", "pools": pools}

wj(os.path.join(LOOT, "forest_forgotten.json"), loot("forest_heart", "minecraft:enchanted_golden_apple"))
wj(os.path.join(LOOT, "crimson_parasite.json"), loot("crimson_core", "minecraft:totem_of_undying"))
wj(os.path.join(LOOT, "sculk_shadow.json"), loot("shadow_essence", "minecraft:enchanted_golden_apple"))

for heart, sword_n in (("forest_heart", "root_blade"), ("crimson_core", "crimson_fang"), ("shadow_essence", "shadow_blade")):
    wj(os.path.join(RECIPES, sword_n + ".json"), {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": [" H ", " N ", " S "],
        "key": {"H": {"item": "%s:%s" % (MOD, heart)}, "N": {"item": "minecraft:netherite_ingot"}, "S": {"item": "minecraft:stick"}},
        "result": {"item": "%s:%s" % (MOD, sword_n)}})

# önizleme: eşya ızgarası
sheet = Image.new("RGBA", (16 * 6, 16), (24, 24, 28, 255))
for i, n in enumerate(items): sheet.alpha_composite(Image.open(os.path.join(TEX_ITEM, n + ".png")), (i * 16, 0))
sheet.resize((16 * 6 * 8, 128), Image.NEAREST).save(os.path.join(PREVIEW, "esyalar.png"))
print("Tamam.")
