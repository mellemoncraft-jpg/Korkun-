# Korkunç Canavarlar — Minecraft Java boss modu (Fabric 1.20.1)

3 özgün boss: kendi modeli, dokusu (parlayan gözler/çekirdek dahil), boss çubuğu, 2. fazı, yetenekleri, ganimeti ve kılıcı var.

| Boss | Can | Yetenekler | Zayıflık |
|---|---|---|---|
| **Orman Unutulanı** (ağaç golem) | 320 | Kök Patlaması, Spor Bulutu, Yer Sarsıntısı, gün ışığında yenilenme | Ateş x1.6, balta x1.3 |
| **Kızıl Parazit** (makine-et iskelet) | 260 | Kan Emme, Atılma, Dokunaç Kancası (çeker), Parazit Sürüsü, Kan Nabzı (2. faz) | Zehir bağışık, hızlı ama az canlı |
| **Skulk Gölgesi** (uçan, 4 kollu) | 340 | Karanlık Aura, Sonik Çığlık, Gölge Adımı, Skulk Çığlığı (2. faz) | Aydınlıkta +%30 hasar |

Hepsi canı %50'nin altına inince 2. faza geçer (boss çubuğu rengi değişir, gökyüzü kararır, saldırılar sertleşir).

## Ganimet
Orman Kalbi / Kızıl Çekirdek / Skulk Özü + elmas + netherite parçası (+ %30 büyük ödül).
Kılıçlar: `[boş] [Kalp/Çekirdek/Öz] [boş]` / `[boş] [Netherite Külçe] [boş]` / `[boş] [Çubuk] [boş]` ile üretilir.

## Çağırma
Yaratıcı envanterinde "Korkunç Canavarlar" sekmesi veya:
`/summon korkunc:forest_forgotten` · `/summon korkunc:crimson_parasite` · `/summon korkunc:sculk_shadow`
(Barışçıl zorlukta hostile mob'lar silinir; Kolay veya üstünü kullan.)

## Derleme (bilgisayarda)
1. JDK 17 + Gradle 8.5 kur (veya IntelliJ IDEA ile klasörü aç, Gradle'ı senkronla).
2. Klasörde `gradle wrapper` çalıştır, sonra `./gradlew build` (Windows: `gradlew build`).
3. `build/libs/korkunc-canavarlar-1.0.0.jar` dosyasını Fabric 1.20.1 `mods` klasörüne at (Fabric API de gerekir).

## Modelleri/dokuları düzenleme
`tools/generate_assets.py` hem Java model sınıflarını hem PNG dokuları üretir. Parça listelerini (PART) düzenle,
`python3 tools/generate_assets.py` çalıştır. `preview/` klasöründe doku önizlemeleri var.
Dokuyu elle boyamak istersen PNG'leri `src/main/resources/assets/korkunc/textures/entity/` içinde düzenle
(`*_glow.png` karanlıkta parlayan kısımlardır). Blockbench ile de açabilirsin.

## Not
Bu kod bu ortamda DERLENİP OYUNDA TEST EDİLEMEDİ (internet/Minecraft kütüphaneleri yok). Küçük Yarn isim farkları
çıkarsa derleyici hatayı satırıyla söyler; genelde tek kelimelik düzeltmedir.
